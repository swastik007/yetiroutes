<?php
$pageTitle = 'Meet Our Expert Guides';
$metaDescription = 'Meet the experienced mountain guides of Yeti Routes. Certified professionals with decades of Himalayan expertise.';
ob_start();
?>

<!-- Hero Section -->
<section class="relative h-96 overflow-hidden">
    <img src="https://images.unsplash.com/photo-1519904981063-b0cf448d479e?w=1920" alt="Our Guides" class="w-full h-full object-cover">
    <div class="absolute inset-0 bg-black bg-opacity-60 flex items-center">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-5xl md:text-6xl font-bold text-white mb-4">Meet Our Guides</h1>
            <p class="text-xl text-gray-200 max-w-2xl mx-auto">The heart and soul of Yeti Routes - experienced, certified, and passionate about the mountains</p>
        </div>
    </div>
</section>

<!-- Intro Section -->
<section class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto text-center">
            <h2 class="text-3xl font-bold mb-6">Why Our Guides Make the Difference</h2>
            <p class="text-lg text-gray-700 leading-relaxed mb-8">
                At Yeti Routes, our guides aren't just leading you through the mountains—they're sharing their home, their culture, and their deep knowledge of the Himalayas. Each guide brings years of experience, government certification, and most importantly, a genuine passion for creating unforgettable experiences.
            </p>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
                <div class="text-center">
                    <div class="text-4xl font-bold text-blue-600 mb-2">15+</div>
                    <div class="text-gray-600">Expert Guides</div>
                </div>
                <div class="text-center">
                    <div class="text-4xl font-bold text-green-600 mb-2">100%</div>
                    <div class="text-gray-600">Certified</div>
                </div>
                <div class="text-center">
                    <div class="text-4xl font-bold text-purple-600 mb-2">10+</div>
                    <div class="text-gray-600">Avg Years Exp</div>
                </div>
                <div class="text-center">
                    <div class="text-4xl font-bold text-orange-600 mb-2">8</div>
                    <div class="text-gray-600">Languages</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Lead Guides -->
<section class="py-20 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold mb-4">Our Senior Guides</h2>
            <p class="text-xl text-gray-600">Meet the leaders of our trekking team</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!-- Guide 1 -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden hover-scale">
                <div class="relative h-80">
                    <img src="https://i.pravatar.cc/400?img=13" alt="Pemba Sherpa" class="w-full h-full object-cover">
                    <div class="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black to-transparent text-white">
                        <h3 class="text-2xl font-bold mb-1">Pemba Sherpa</h3>
                        <p class="text-blue-300">Lead Guide & Co-Founder</p>
                    </div>
                </div>
                <div class="p-6">
                    <div class="flex items-center mb-4 text-sm text-gray-600">
                        <span class="mr-4"><i class="fas fa-mountain text-blue-600 mr-1"></i> 15 Years</span>
                        <span><i class="fas fa-language text-green-600 mr-1"></i> English, Nepali</span>
                    </div>
                    <p class="text-gray-700 mb-4">Born in the Khumbu region, Pemba has summited Everest 5 times and led over 300 successful treks. His deep knowledge of the region and warm personality make every trek special.</p>

                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">Certifications:</h4>
                        <ul class="text-sm text-gray-600 space-y-1">
                            <li><i class="fas fa-check text-green-600 mr-2"></i>Nepal Tourism Board Licensed</li>
                            <li><i class="fas fa-check text-green-600 mr-2"></i>Wilderness First Responder</li>
                            <li><i class="fas fa-check text-green-600 mr-2"></i>High Altitude Guide (6000m+)</li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">Specialties:</h4>
                        <div class="flex flex-wrap gap-2">
                            <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">Everest Region</span>
                            <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">High Altitude</span>
                        </div>
                    </div>

                    <div class="border-t pt-4">
                        <div class="text-sm text-gray-600">
                            <i class="fas fa-quote-left text-gray-400 mr-2"></i>
                            <em>"The mountains are my home, and I love sharing their magic with trekkers from around the world."</em>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Guide 2 -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden hover-scale">
                <div class="relative h-80">
                    <img src="https://i.pravatar.cc/400?img=14" alt="Lakpa Tamang" class="w-full h-full object-cover">
                    <div class="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black to-transparent text-white">
                        <h3 class="text-2xl font-bold mb-1">Lakpa Tamang</h3>
                        <p class="text-blue-300">Senior Trek Leader</p>
                    </div>
                </div>
                <div class="p-6">
                    <div class="flex items-center mb-4 text-sm text-gray-600">
                        <span class="mr-4"><i class="fas fa-mountain text-blue-600 mr-1"></i> 12 Years</span>
                        <span><i class="fas fa-language text-green-600 mr-1"></i> English, French, Nepali</span>
                    </div>
                    <p class="text-gray-700 mb-4">Lakpa specializes in the Langtang and Manaslu regions. His expertise in Tibetan Buddhism and local culture adds a unique dimension to every trek.</p>

                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">Certifications:</h4>
                        <ul class="text-sm text-gray-600 space-y-1">
                            <li><i class="fas fa-check text-green-600 mr-2"></i>Nepal Tourism Board Licensed</li>
                            <li><i class="fas fa-check text-green-600 mr-2"></i>First Aid Certified</li>
                            <li><i class="fas fa-check text-green-600 mr-2"></i>Cultural Heritage Guide</li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">Specialties:</h4>
                        <div class="flex flex-wrap gap-2">
                            <span class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">Langtang</span>
                            <span class="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm">Cultural Tours</span>
                        </div>
                    </div>

                    <div class="border-t pt-4">
                        <div class="text-sm text-gray-600">
                            <i class="fas fa-quote-left text-gray-400 mr-2"></i>
                            <em>"Every trek is a journey not just through mountains, but through culture and spirituality."</em>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Guide 3 -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden hover-scale">
                <div class="relative h-80">
                    <img src="https://i.pravatar.cc/400?img=11" alt="Dawa Lama" class="w-full h-full object-cover">
                    <div class="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black to-transparent text-white">
                        <h3 class="text-2xl font-bold mb-1">Dawa Lama</h3>
                        <p class="text-blue-300">Annapurna Specialist</p>
                    </div>
                </div>
                <div class="p-6">
                    <div class="flex items-center mb-4 text-sm text-gray-600">
                        <span class="mr-4"><i class="fas fa-mountain text-blue-600 mr-1"></i> 10 Years</span>
                        <span><i class="fas fa-language text-green-600 mr-1"></i> English, German, Nepali</span>
                    </div>
                    <p class="text-gray-700 mb-4">Growing up in the Annapurna foothills, Dawa knows every trail and teahouse in the region. His attention to detail ensures smooth, memorable treks.</p>

                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">Certifications:</h4>
                        <ul class="text-sm text-gray-600 space-y-1">
                            <li><i class="fas fa-check text-green-600 mr-2"></i>Nepal Tourism Board Licensed</li>
                            <li><i class="fas fa-check text-green-600 mr-2"></i>Emergency Response Trained</li>
                            <li><i class="fas fa-check text-green-600 mr-2"></i>Eco-Tourism Certified</li>
                        </ul>
                    </div>

                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">Specialties:</h4>
                        <div class="flex flex-wrap gap-2">
                            <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">Annapurna</span>
                            <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">Eco-Trekking</span>
                        </div>
                    </div>

                    <div class="border-t pt-4">
                        <div class="text-sm text-gray-600">
                            <i class="fas fa-quote-left text-gray-400 mr-2"></i>
                            <em>"The Annapurna region is paradise. Let me show you why."</em>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Assistant Guides -->
<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold mb-4">Our Assistant Guides</h2>
            <p class="text-lg text-gray-600">Young, energetic, and passionate about trekking</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <?php
            $assistantGuides = [
                ['name' => 'Mingma Sherpa', 'exp' => '8 Years', 'region' => 'Everest', 'img' => 15],
                ['name' => 'Nima Dorje', 'exp' => '7 Years', 'region' => 'Manaslu', 'img' => 16],
                ['name' => 'Pasang Lhamu', 'exp' => '6 Years', 'region' => 'Annapurna', 'img' => 5],
                ['name' => 'Karma Gyaltsen', 'exp' => '5 Years', 'region' => 'Langtang', 'img' => 12],
            ];
            foreach ($assistantGuides as $guide): ?>
                <div class="bg-gray-50 rounded-xl p-6 text-center">
                    <img src="https://i.pravatar.cc/150?img=<?= $guide['img'] ?>" alt="<?= $guide['name'] ?>" class="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-blue-600">
                    <h3 class="font-bold text-lg mb-1"><?= $guide['name'] ?></h3>
                    <p class="text-blue-600 mb-2">Assistant Guide</p>
                    <p class="text-sm text-gray-600 mb-1"><i class="fas fa-mountain mr-1"></i><?= $guide['exp'] ?></p>
                    <p class="text-sm text-gray-600"><i class="fas fa-map-marker-alt mr-1"></i><?= $guide['region'] ?> Specialist</p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Guide Qualifications -->
<section class="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-4xl font-bold mb-12 text-center">What Makes Our Guides Special</h2>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="flex items-start">
                    <div class="flex-shrink-0 w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-certificate text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-2">Government Certified</h3>
                        <p>All guides hold valid licenses from Nepal Tourism Board and undergo regular training updates.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-first-aid text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-2">First Aid Trained</h3>
                        <p>Wilderness First Responder certification and altitude sickness recognition training.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-language text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-2">Multi-Lingual</h3>
                        <p>Fluent in English plus additional languages including French, German, Spanish, and Japanese.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-heart text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-2">Local Knowledge</h3>
                        <p>Born and raised in mountain communities with deep cultural and geographical expertise.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-users text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-2">People Skills</h3>
                        <p>Friendly, patient, and excellent at reading group dynamics to ensure everyone enjoys the trek.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-shield-alt text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-2">Safety Focus</h3>
                        <p>Extensive experience in emergency response, evacuation procedures, and risk management.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="py-20 bg-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-4xl font-bold mb-6">Trek with the Best</h2>
        <p class="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Our guides are waiting to share their knowledge, passion, and the beauty of the Himalayas with you
        </p>
        <div class="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/treks" class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fas fa-mountain mr-2"></i> Browse Our Treks
            </a>
            <a href="/contact" class="bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fas fa-envelope mr-2"></i> Get in Touch
            </a>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/frontend.php';
?>
