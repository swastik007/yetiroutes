<?php
$pageTitle = 'Travel Information - Nepal Trekking Guide';
$metaDescription = 'Essential travel information for trekking in Nepal - permits, weather, packing lists, fitness requirements, altitude sickness prevention, and more.';
ob_start();
?>

<!-- Hero Section -->
<section class="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20">
    <div class="container mx-auto px-4">
        <div class="max-w-3xl mx-auto text-center">
            <h1 class="text-5xl font-bold mb-4">Travel Information</h1>
            <p class="text-xl">Everything you need to know for trekking in Nepal</p>
        </div>
    </div>
</section>

<!-- Quick Links Navigation -->
<section class="bg-white shadow-md sticky top-16 z-40">
    <div class="container mx-auto px-4">
        <div class="flex overflow-x-auto py-4 space-x-6">
            <a href="#permits" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">Permits & Visas</a>
            <a href="#best-time" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">Best Time to Trek</a>
            <a href="#packing" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">Packing List</a>
            <a href="#fitness" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">Fitness & Training</a>
            <a href="#altitude" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">Altitude Sickness</a>
            <a href="#accommodation" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">Accommodation</a>
            <a href="#insurance" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">Travel Insurance</a>
            <a href="#faq" class="whitespace-nowrap text-gray-700 hover:text-blue-600 font-semibold">FAQ</a>
        </div>
    </div>
</section>

<!-- Main Content -->
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">

        <!-- Permits & Visas -->
        <div id="permits" class="mb-16 scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-6 flex items-center">
                    <i class="fas fa-passport text-blue-600 mr-4"></i>
                    Permits & Visas
                </h2>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                    <div>
                        <h3 class="text-2xl font-bold mb-4">Nepal Tourist Visa</h3>
                        <ul class="space-y-3">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-3 mt-1"></i>
                                <div>
                                    <strong>15 Days:</strong> $30 USD
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-3 mt-1"></i>
                                <div>
                                    <strong>30 Days:</strong> $50 USD
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-3 mt-1"></i>
                                <div>
                                    <strong>90 Days:</strong> $125 USD
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-info-circle text-blue-600 mr-3 mt-1"></i>
                                <div>
                                    Available on arrival at Tribhuvan Airport or land borders
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-info-circle text-blue-600 mr-3 mt-1"></i>
                                <div>
                                    Bring 2 passport photos and exact cash (USD)
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div>
                        <h3 class="text-2xl font-bold mb-4">Trekking Permits Required</h3>
                        <div class="space-y-4">
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <h4 class="font-bold mb-2">TIMS Card (Trekkers' Information Management System)</h4>
                                <p class="text-gray-600">Required for most trekking regions</p>
                                <p class="font-semibold text-blue-600 mt-2">$10-20 USD</p>
                            </div>
                            <div class="bg-green-50 p-4 rounded-lg">
                                <h4 class="font-bold mb-2">National Park Entry Permits</h4>
                                <p class="text-gray-600">Sagarmatha, Annapurna, Langtang, etc.</p>
                                <p class="font-semibold text-green-600 mt-2">$20-30 USD</p>
                            </div>
                            <div class="bg-purple-50 p-4 rounded-lg">
                                <h4 class="font-bold mb-2">Special Permits</h4>
                                <p class="text-gray-600">Restricted areas (Manaslu, Upper Mustang)</p>
                                <p class="font-semibold text-purple-600 mt-2">$50-500 USD</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded">
                    <p class="font-semibold text-yellow-800">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        We handle all permit arrangements for you! Permits are included in our trek packages.
                    </p>
                </div>
            </div>
        </div>

        <!-- Best Time to Trek -->
        <div id="best-time" class="mb-16 scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-6 flex items-center">
                    <i class="fas fa-calendar-alt text-blue-600 mr-4"></i>
                    Best Time to Trek
                </h2>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <!-- Spring -->
                    <div class="bg-green-50 p-6 rounded-xl border-2 border-green-500">
                        <h3 class="text-2xl font-bold mb-2 text-green-800">Spring</h3>
                        <p class="text-xl font-semibold mb-3">March - May</p>
                        <div class="mb-4">
                            <div class="flex items-center mb-2">
                                <i class="fas fa-star text-yellow-500 mr-2"></i>
                                <span class="font-semibold">Peak Season</span>
                            </div>
                        </div>
                        <ul class="space-y-2 text-sm">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Clear skies & excellent views</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Rhododendrons in bloom</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Warmer temperatures</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-times text-red-600 mr-2 mt-1"></i>
                                <span>More crowded trails</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Summer -->
                    <div class="bg-gray-50 p-6 rounded-xl border-2 border-gray-300">
                        <h3 class="text-2xl font-bold mb-2 text-gray-800">Summer</h3>
                        <p class="text-xl font-semibold mb-3">June - August</p>
                        <div class="mb-4">
                            <div class="flex items-center mb-2">
                                <i class="fas fa-cloud-rain text-blue-500 mr-2"></i>
                                <span class="font-semibold">Monsoon Season</span>
                            </div>
                        </div>
                        <ul class="space-y-2 text-sm">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Fewer tourists</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Lush green landscapes</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-times text-red-600 mr-2 mt-1"></i>
                                <span>Heavy rainfall</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-times text-red-600 mr-2 mt-1"></i>
                                <span>Cloudy mountain views</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Autumn -->
                    <div class="bg-orange-50 p-6 rounded-xl border-2 border-orange-500">
                        <h3 class="text-2xl font-bold mb-2 text-orange-800">Autumn</h3>
                        <p class="text-xl font-semibold mb-3">Sept - Nov</p>
                        <div class="mb-4">
                            <div class="flex items-center mb-2">
                                <i class="fas fa-star text-yellow-500 mr-2"></i>
                                <span class="font-semibold">Peak Season</span>
                            </div>
                        </div>
                        <ul class="space-y-2 text-sm">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Best weather conditions</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Crystal clear views</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Stable temperatures</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-times text-red-600 mr-2 mt-1"></i>
                                <span>Most crowded season</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Winter -->
                    <div class="bg-blue-50 p-6 rounded-xl border-2 border-blue-300">
                        <h3 class="text-2xl font-bold mb-2 text-blue-800">Winter</h3>
                        <p class="text-xl font-semibold mb-3">Dec - Feb</p>
                        <div class="mb-4">
                            <div class="flex items-center mb-2">
                                <i class="fas fa-snowflake text-blue-500 mr-2"></i>
                                <span class="font-semibold">Off Season</span>
                            </div>
                        </div>
                        <ul class="space-y-2 text-sm">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Empty trails</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Lower altitudes still good</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-times text-red-600 mr-2 mt-1"></i>
                                <span>Very cold at high altitude</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-times text-red-600 mr-2 mt-1"></i>
                                <span>Some passes may be closed</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="bg-blue-50 p-6 rounded-lg">
                    <h3 class="text-xl font-bold mb-3">Our Recommendation</h3>
                    <p class="text-gray-700">October and April are the sweet spots - great weather with slightly fewer crowds than peak months. However, we operate treks year-round with appropriate route adjustments.</p>
                </div>
            </div>
        </div>

        <!-- Packing List -->
        <div id="packing" class="mb-16 scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-6 flex items-center">
                    <i class="fas fa-suitcase text-blue-600 mr-4"></i>
                    Essential Packing List
                </h2>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <!-- Clothing -->
                    <div>
                        <h3 class="text-2xl font-bold mb-4 text-blue-600">Clothing</h3>
                        <ul class="space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Moisture-wicking base layers (3-4)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Insulating mid-layers (fleece/down)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Waterproof jacket & pants</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Down jacket (for high altitude)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Trekking pants (2-3 pairs)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Warm hat & sun hat</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Gloves (liner + warm)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Trekking socks (4-5 pairs)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Underwear (quick-dry)</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Footwear & Gear -->
                    <div>
                        <h3 class="text-2xl font-bold mb-4 text-purple-600">Footwear & Gear</h3>
                        <ul class="space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Broken-in hiking boots</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Camp shoes/sandals</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Backpack (40-50L)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Sleeping bag (-10°C rated)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Trekking poles</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Headlamp + extra batteries</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Sunglasses (UV protection)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Water bottles/hydration system (3L)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Dry bags/stuff sacks</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Personal & Medical -->
                    <div>
                        <h3 class="text-2xl font-bold mb-4 text-orange-600">Personal & Medical</h3>
                        <ul class="space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>First aid kit</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Altitude sickness medication (Diamox)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Personal medications</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Sunscreen (SPF 50+)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Lip balm (SPF)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Toiletries (biodegradable)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Wet wipes/hand sanitizer</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Water purification tablets</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Camera + extra batteries</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Power bank</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="mt-8 bg-green-50 p-6 rounded-lg">
                    <h4 class="font-bold text-lg mb-2"><i class="fas fa-download mr-2"></i>Download Complete Packing List</h4>
                    <p class="text-gray-600 mb-4">Get our comprehensive PDF packing list with region-specific recommendations</p>
                    <a href="/downloads/packing-list.pdf" class="inline-block bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold">
                        <i class="fas fa-file-pdf mr-2"></i> Download PDF
                    </a>
                </div>
            </div>
        </div>

        <!-- Fitness & Training -->
        <div id="fitness" class="mb-16 scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-6 flex items-center">
                    <i class="fas fa-dumbbell text-blue-600 mr-4"></i>
                    Fitness & Training
                </h2>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <h3 class="text-2xl font-bold mb-4">Fitness Requirements by Difficulty</h3>

                        <div class="space-y-4">
                            <div class="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
                                <h4 class="font-bold text-lg mb-2">Easy Treks</h4>
                                <p class="text-gray-600">Basic fitness level. Ability to walk 4-5 hours daily.</p>
                            </div>

                            <div class="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                                <h4 class="font-bold text-lg mb-2">Moderate Treks</h4>
                                <p class="text-gray-600">Good fitness. Comfortable walking 5-6 hours with elevation gain.</p>
                            </div>

                            <div class="bg-orange-50 p-4 rounded-lg border-l-4 border-orange-500">
                                <h4 class="font-bold text-lg mb-2">Challenging Treks</h4>
                                <p class="text-gray-600">Excellent fitness. 6-7 hours daily, high altitude endurance.</p>
                            </div>

                            <div class="bg-red-50 p-4 rounded-lg border-l-4 border-red-500">
                                <h4 class="font-bold text-lg mb-2">Extreme Treks</h4>
                                <p class="text-gray-600">Peak physical condition. Technical skills, high altitude experience.</p>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-2xl font-bold mb-4">Recommended Training Program</h3>
                        <p class="text-gray-600 mb-4">Start training 2-3 months before your trek:</p>

                        <div class="space-y-3">
                            <div class="flex items-start">
                                <div class="bg-blue-100 rounded-full p-2 mr-3">
                                    <i class="fas fa-walking text-blue-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold">Cardiovascular Training</h4>
                                    <p class="text-sm text-gray-600">30-60 min, 4-5x per week (hiking, running, cycling)</p>
                                </div>
                            </div>

                            <div class="flex items-start">
                                <div class="bg-purple-100 rounded-full p-2 mr-3">
                                    <i class="fas fa-dumbbell text-purple-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold">Strength Training</h4>
                                    <p class="text-sm text-gray-600">Focus on legs, core, back - 2-3x per week</p>
                                </div>
                            </div>

                            <div class="flex items-start">
                                <div class="bg-green-100 rounded-full p-2 mr-3">
                                    <i class="fas fa-mountain text-green-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold">Hill/Stair Training</h4>
                                    <p class="text-sm text-gray-600">Practice uphill with weighted backpack weekly</p>
                                </div>
                            </div>

                            <div class="flex items-start">
                                <div class="bg-orange-100 rounded-full p-2 mr-3">
                                    <i class="fas fa-shoe-prints text-orange-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold">Long Hikes</h4>
                                    <p class="text-sm text-gray-600">4-6 hour hikes on weekends to build endurance</p>
                                </div>
                            </div>

                            <div class="flex items-start">
                                <div class="bg-yellow-100 rounded-full p-2 mr-3">
                                    <i class="fas fa-lungs text-yellow-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold">Breathing Exercises</h4>
                                    <p class="text-sm text-gray-600">Practice controlled breathing for altitude</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Altitude Sickness -->
        <div id="altitude" class="mb-16 scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-6 flex items-center">
                    <i class="fas fa-heartbeat text-red-600 mr-4"></i>
                    Altitude Sickness Prevention
                </h2>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                    <div class="md:col-span-2">
                        <h3 class="text-2xl font-bold mb-4">What is Altitude Sickness?</h3>
                        <p class="text-gray-600 mb-4">Acute Mountain Sickness (AMS) occurs when you ascend too quickly to high altitude (above 2,500m/8,200ft). Reduced oxygen levels can cause symptoms ranging from mild to life-threatening.</p>

                        <h4 class="text-xl font-bold mb-3">Symptoms to Watch For:</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <div>
                                <h5 class="font-bold text-yellow-600 mb-2">Mild Symptoms:</h5>
                                <ul class="space-y-1 text-sm">
                                    <li><i class="fas fa-circle text-yellow-500 mr-2" style="font-size: 6px;"></i>Headache</li>
                                    <li><i class="fas fa-circle text-yellow-500 mr-2" style="font-size: 6px;"></i>Fatigue</li>
                                    <li><i class="fas fa-circle text-yellow-500 mr-2" style="font-size: 6px;"></i>Nausea</li>
                                    <li><i class="fas fa-circle text-yellow-500 mr-2" style="font-size: 6px;"></i>Dizziness</li>
                                    <li><i class="fas fa-circle text-yellow-500 mr-2" style="font-size: 6px;"></i>Loss of appetite</li>
                                </ul>
                            </div>
                            <div>
                                <h5 class="font-bold text-red-600 mb-2">Severe Symptoms (Seek Help!):</h5>
                                <ul class="space-y-1 text-sm">
                                    <li><i class="fas fa-circle text-red-500 mr-2" style="font-size: 6px;"></i>Severe headache</li>
                                    <li><i class="fas fa-circle text-red-500 mr-2" style="font-size: 6px;"></i>Confusion</li>
                                    <li><i class="fas fa-circle text-red-500 mr-2" style="font-size: 6px;"></i>Difficulty breathing at rest</li>
                                    <li><i class="fas fa-circle text-red-500 mr-2" style="font-size: 6px;"></i>Chest tightness</li>
                                    <li><i class="fas fa-circle text-red-500 mr-2" style="font-size: 6px;"></i>Loss of coordination</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="bg-red-50 p-6 rounded-lg">
                        <h4 class="font-bold text-lg mb-3 text-red-800">Emergency Protocol</h4>
                        <ol class="space-y-2 text-sm">
                            <li class="flex items-start">
                                <span class="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">1</span>
                                <span>Stop ascending immediately</span>
                            </li>
                            <li class="flex items-start">
                                <span class="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">2</span>
                                <span>Inform your guide</span>
                            </li>
                            <li class="flex items-start">
                                <span class="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">3</span>
                                <span>Rest and hydrate</span>
                            </li>
                            <li class="flex items-start">
                                <span class="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">4</span>
                                <span>Descend if no improvement</span>
                            </li>
                            <li class="flex items-start">
                                <span class="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">5</span>
                                <span>Seek medical help if severe</span>
                            </li>
                        </ol>
                    </div>
                </div>

                <h3 class="text-2xl font-bold mb-4">Prevention Tips</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <i class="fas fa-route text-blue-600 text-2xl mb-2"></i>
                        <h4 class="font-bold mb-2">Ascend Gradually</h4>
                        <p class="text-sm text-gray-600">Don't climb more than 300-500m per day above 3,000m</p>
                    </div>

                    <div class="bg-green-50 p-4 rounded-lg">
                        <i class="fas fa-bed text-green-600 text-2xl mb-2"></i>
                        <h4 class="font-bold mb-2">Climb High, Sleep Low</h4>
                        <p class="text-sm text-gray-600">Acclimatization hikes during the day, sleep lower</p>
                    </div>

                    <div class="bg-purple-50 p-4 rounded-lg">
                        <i class="fas fa-tint text-purple-600 text-2xl mb-2"></i>
                        <h4 class="font-bold mb-2">Stay Hydrated</h4>
                        <p class="text-sm text-gray-600">Drink 3-4 liters of water daily</p>
                    </div>

                    <div class="bg-orange-50 p-4 rounded-lg">
                        <i class="fas fa-utensils text-orange-600 text-2xl mb-2"></i>
                        <h4 class="font-bold mb-2">Eat Well</h4>
                        <p class="text-sm text-gray-600">High-carb diet helps with acclimatization</p>
                    </div>

                    <div class="bg-yellow-50 p-4 rounded-lg">
                        <i class="fas fa-ban text-yellow-600 text-2xl mb-2"></i>
                        <h4 class="font-bold mb-2">Avoid Alcohol</h4>
                        <p class="text-sm text-gray-600">No alcohol for first 48 hours at altitude</p>
                    </div>

                    <div class="bg-pink-50 p-4 rounded-lg">
                        <i class="fas fa-pills text-pink-600 text-2xl mb-2"></i>
                        <h4 class="font-bold mb-2">Consider Diamox</h4>
                        <p class="text-sm text-gray-600">Consult doctor about altitude medication</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Accommodation -->
        <div id="accommodation" class="mb-16 scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-6 flex items-center">
                    <i class="fas fa-home text-blue-600 mr-4"></i>
                    Accommodation on Treks
                </h2>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <h3 class="text-2xl font-bold mb-4">Teahouse Lodges</h3>
                        <img src="https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600" alt="Teahouse" class="rounded-lg mb-4 w-full h-48 object-cover">
                        <p class="text-gray-600 mb-4">Most treks use teahouse lodges - family-run guesthouses along the trail.</p>

                        <h4 class="font-bold mb-2">What to Expect:</h4>
                        <ul class="space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Basic but comfortable twin rooms</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Shared bathrooms (most locations)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Communal dining area with fireplace</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Hot showers available (extra charge)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Charging stations (fee applies)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>WiFi at lower altitudes</span>
                            </li>
                        </ul>
                    </div>

                    <div>
                        <h3 class="text-2xl font-bold mb-4">Camping Treks</h3>
                        <img src="https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=600" alt="Camping" class="rounded-lg mb-4 w-full h-48 object-cover">
                        <p class="text-gray-600 mb-4">For remote areas without teahouses, we provide full camping setups.</p>

                        <h4 class="font-bold mb-2">Camping Includes:</h4>
                        <ul class="space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Quality tents (sleeping & dining)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Sleeping mats and pillows</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Toilet tent with facilities</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Kitchen tent & crew</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Fresh meals prepared daily</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>All camping equipment</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Travel Insurance -->
        <div id="insurance" class="mb-16 scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-6 flex items-center">
                    <i class="fas fa-shield-alt text-blue-600 mr-4"></i>
                    Travel Insurance
                </h2>

                <div class="bg-red-50 border-l-4 border-red-500 p-6 mb-8">
                    <h3 class="text-xl font-bold text-red-800 mb-2">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        MANDATORY REQUIREMENT
                    </h3>
                    <p class="text-gray-700">Comprehensive travel insurance is REQUIRED for all treks. You must provide proof of insurance before departure.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <h3 class="text-2xl font-bold mb-4">Required Coverage</h3>
                        <ul class="space-y-3">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-600 mr-3 mt-1 text-xl"></i>
                                <div>
                                    <strong>Emergency Medical Evacuation</strong>
                                    <p class="text-sm text-gray-600">Helicopter rescue up to $100,000 minimum</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-600 mr-3 mt-1 text-xl"></i>
                                <div>
                                    <strong>Medical Treatment</strong>
                                    <p class="text-sm text-gray-600">Coverage for altitude-related illnesses</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-600 mr-3 mt-1 text-xl"></i>
                                <div>
                                    <strong>Trip Cancellation</strong>
                                    <p class="text-sm text-gray-600">Covers non-refundable trek costs</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-600 mr-3 mt-1 text-xl"></i>
                                <div>
                                    <strong>Adventure Sports Coverage</strong>
                                    <p class="text-sm text-gray-600">Must explicitly cover trekking/mountaineering</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-600 mr-3 mt-1 text-xl"></i>
                                <div>
                                    <strong>Personal Liability</strong>
                                    <p class="text-sm text-gray-600">Third-party liability coverage</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-600 mr-3 mt-1 text-xl"></i>
                                <div>
                                    <strong>Lost/Stolen Baggage</strong>
                                    <p class="text-sm text-gray-600">Coverage for personal belongings</p>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div>
                        <h3 class="text-2xl font-bold mb-4">Recommended Providers</h3>
                        <div class="space-y-4">
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <h4 class="font-bold">World Nomads</h4>
                                <p class="text-sm text-gray-600 mb-2">Popular with trekkers, covers up to 6,000m</p>
                                <a href="https://worldnomads.com" target="_blank" class="text-blue-600 hover:underline text-sm">worldnomads.com →</a>
                            </div>

                            <div class="bg-green-50 p-4 rounded-lg">
                                <h4 class="font-bold">IMG Global</h4>
                                <p class="text-sm text-gray-600 mb-2">Comprehensive coverage, good for longer trips</p>
                                <a href="https://imglobal.com" target="_blank" class="text-green-600 hover:underline text-sm">imglobal.com →</a>
                            </div>

                            <div class="bg-purple-50 p-4 rounded-lg">
                                <h4 class="font-bold">True Traveller</h4>
                                <p class="text-sm text-gray-600 mb-2">UK-based, covers trekking up to 6,400m</p>
                                <a href="https://truetraveller.com" target="_blank" class="text-purple-600 hover:underline text-sm">truetraveller.com →</a>
                            </div>
                        </div>

                        <div class="mt-6 bg-yellow-50 p-4 rounded-lg">
                            <p class="text-sm">
                                <i class="fas fa-info-circle text-yellow-600 mr-2"></i>
                                <strong>Important:</strong> Read policy carefully. Ensure your maximum trekking altitude is covered!
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- FAQ -->
        <div id="faq" class="scroll-mt-32">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-4xl font-bold mb-8 text-center">Frequently Asked Questions</h2>

                <div class="space-y-4 max-w-4xl mx-auto">
                    <?php
                    $faqs = [
                        ['q' => 'Do I need previous trekking experience?', 'a' => 'No! We have treks for all levels. Beginners should start with easier routes like Poon Hill or Ghorepani. Our guides will support you throughout.'],
                        ['q' => 'Can I trek solo or do I need a guide?', 'a' => 'While independent trekking is possible on some routes, we strongly recommend going with a guide for safety, navigation, cultural insights, and support in emergencies.'],
                        ['q' => 'What about electricity and charging devices?', 'a' => 'Most teahouses have charging stations (₹200-500 per charge). Bring a power bank as backup. Solar chargers are also useful for longer treks.'],
                        ['q' => 'Is WiFi available on treks?', 'a' => 'Many lower-altitude lodges offer WiFi ($3-5/day). Connectivity decreases with altitude. We recommend disconnecting and enjoying the experience!'],
                        ['q' => 'What food is available on treks?', 'a' => 'Teahouses serve Nepali (dal bhat), Tibetan (momos), and Western meals (pasta, pizza). Portions are generous. We accommodate vegetarian/vegan diets easily.'],
                        ['q' => 'How much cash should I bring?', 'a' => 'ATMs are only in major towns. Bring enough Nepali Rupees for snacks, drinks, hot showers ($3-5), charging ($2-3), and tips. Budget $10-20/day extra.'],
                        ['q' => 'What about bathrooms on the trail?', 'a' => 'Teahouses have squat or Western toilets (varying quality). Toilet paper not always provided - bring your own. Hand sanitizer is essential.'],
                        ['q' => 'Can I do laundry during the trek?', 'a' => 'Limited laundry services at lower altitudes ($5-10). At high altitude, bring quick-dry clothing and plan to re-wear items.'],
                        ['q' => 'Are there age limits for trekking?', 'a' => 'No strict limits. We\'ve had trekkers from 8 to 78! What matters is fitness level and choosing an appropriate route. Consult your doctor.'],
                        ['q' => 'What if I need to leave the trek early?', 'a' => 'You can always descend with a guide. Helicopter evacuation is available for emergencies (covered by insurance). No refunds for early departure.'],
                    ];

                    foreach ($faqs as $index => $faq):
                    ?>
                        <div class="border border-gray-200 rounded-lg">
                            <button class="faq-toggle w-full px-6 py-4 text-left font-semibold text-lg flex items-center justify-between hover:bg-gray-50">
                                <span><?= $faq['q'] ?></span>
                                <i class="fas fa-chevron-down transition-transform"></i>
                            </button>
                            <div class="faq-content hidden px-6 pb-4 text-gray-600">
                                <p><?= $faq['a'] ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- CTA Section -->
<section class="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-4xl font-bold mb-4">Still Have Questions?</h2>
        <p class="text-xl mb-8">Our trek specialists are here to help you plan the perfect adventure</p>
        <div class="flex flex-wrap justify-center gap-4">
            <a href="/contact" class="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fas fa-envelope mr-2"></i> Contact Us
            </a>
            <a href="https://wa.me/9779841234567" target="_blank" class="bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fab fa-whatsapp mr-2"></i> WhatsApp Chat
            </a>
        </div>
    </div>
</section>

<script>
// Smooth scroll to anchors
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// FAQ Accordion
document.querySelectorAll('.faq-toggle').forEach(button => {
    button.addEventListener('click', () => {
        const content = button.nextElementSibling;
        const icon = button.querySelector('i');

        // Toggle current FAQ
        content.classList.toggle('hidden');
        icon.style.transform = content.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(180deg)';
    });
});
</script>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/frontend.php';
?>
