<?php
$pageTitle = 'Treks & Tours in Nepal';
$metaDescription = 'Browse all our trekking packages in Nepal. Everest, Annapurna, Langtang, Manaslu and more regions.';
ob_start();
?>

<!-- Page Header -->
<section class="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20">
    <div class="container mx-auto px-4">
        <div class="max-w-3xl mx-auto text-center">
            <h1 class="text-5xl font-bold mb-4">Treks & Tours</h1>
            <p class="text-xl">Discover your perfect Himalayan adventure from our curated collection</p>
        </div>
    </div>
</section>

<!-- Filters & Search -->
<section class="bg-white shadow-md sticky top-16 z-40">
    <div class="container mx-auto px-4 py-6">
        <form method="GET" action="/treks" class="grid grid-cols-1 md:grid-cols-5 gap-4">
            <select name="region" class="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                <option value="">All Regions</option>
                <option value="everest" <?= (($_GET['region'] ?? '') === 'everest') ? 'selected' : '' ?>>Everest Region</option>
                <option value="annapurna" <?= (($_GET['region'] ?? '') === 'annapurna') ? 'selected' : '' ?>>Annapurna Region</option>
                <option value="langtang" <?= (($_GET['region'] ?? '') === 'langtang') ? 'selected' : '' ?>>Langtang Region</option>
                <option value="manaslu" <?= (($_GET['region'] ?? '') === 'manaslu') ? 'selected' : '' ?>>Manaslu Region</option>
            </select>

            <select name="duration" class="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                <option value="">Any Duration</option>
                <option value="1-5" <?= (($_GET['duration'] ?? '') === '1-5') ? 'selected' : '' ?>>1-5 Days</option>
                <option value="6-10" <?= (($_GET['duration'] ?? '') === '6-10') ? 'selected' : '' ?>>6-10 Days</option>
                <option value="11-15" <?= (($_GET['duration'] ?? '') === '11-15') ? 'selected' : '' ?>>11-15 Days</option>
                <option value="15+" <?= (($_GET['duration'] ?? '') === '15+') ? 'selected' : '' ?>>15+ Days</option>
            </select>

            <select name="difficulty" class="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                <option value="">All Levels</option>
                <option value="easy" <?= (($_GET['difficulty'] ?? '') === 'easy') ? 'selected' : '' ?>>Easy</option>
                <option value="moderate" <?= (($_GET['difficulty'] ?? '') === 'moderate') ? 'selected' : '' ?>>Moderate</option>
                <option value="challenging" <?= (($_GET['difficulty'] ?? '') === 'challenging') ? 'selected' : '' ?>>Challenging</option>
                <option value="extreme" <?= (($_GET['difficulty'] ?? '') === 'extreme') ? 'selected' : '' ?>>Extreme</option>
            </select>

            <input type="text" name="search" placeholder="Search treks..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" class="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">

            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold">
                <i class="fas fa-search mr-2"></i> Search
            </button>
        </form>
    </div>
</section>

<!-- Treks Grid -->
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-2xl font-bold"><?= $total_routes ?? 0 ?> Treks Found</h2>
            <div class="flex items-center space-x-4">
                <span class="text-gray-600">Sort by:</span>
                <select name="sort" class="px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="popular">Most Popular</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                    <option value="duration">Duration</option>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php if (!empty($routes)): ?>
                <?php foreach ($routes as $route): ?>
                    <div class="bg-white rounded-xl shadow-lg overflow-hidden hover-scale">
                        <div class="relative h-64">
                            <img src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600" alt="<?= htmlspecialchars($route->title) ?>" class="w-full h-full object-cover">
                            <?php if ($route->is_featured): ?>
                                <div class="absolute top-4 right-4 bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                                    <i class="fas fa-star"></i> Featured
                                </div>
                            <?php endif; ?>
                            <div class="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                                <div class="flex items-center justify-between text-white text-sm">
                                    <span><i class="fas fa-clock mr-1"></i> <?= $route->duration_days ?> Days</span>
                                    <span><i class="fas fa-mountain mr-1"></i> <?= number_format($route->max_altitude_meters) ?>m</span>
                                </div>
                            </div>
                        </div>
                        <div class="p-6">
                            <h3 class="text-2xl font-bold mb-2"><?= htmlspecialchars($route->title) ?></h3>
                            <p class="text-gray-600 mb-4 line-clamp-2"><?= htmlspecialchars($route->short_description) ?></p>

                            <div class="flex items-center justify-between mb-4">
                                <span class="px-3 py-1 rounded-full text-sm <?php
                                    echo match($route->difficulty) {
                                        'easy' => 'bg-green-100 text-green-800',
                                        'moderate' => 'bg-blue-100 text-blue-800',
                                        'challenging' => 'bg-orange-100 text-orange-800',
                                        'extreme' => 'bg-red-100 text-red-800',
                                        default => 'bg-gray-100 text-gray-800'
                                    };
                                ?>">
                                    <?= ucfirst($route->difficulty) ?>
                                </span>
                                <span class="text-2xl font-bold text-blue-600">
                                    $<?= number_format($route->base_price) ?>
                                </span>
                            </div>

                            <a href="/trek/<?= htmlspecialchars($route->slug) ?>" class="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center py-3 rounded-lg font-semibold transition">
                                View Details <i class="fas fa-arrow-right ml-2"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-span-3 text-center py-16">
                    <i class="fas fa-mountain text-6xl text-gray-300 mb-4"></i>
                    <h3 class="text-2xl font-bold text-gray-600 mb-2">No treks found</h3>
                    <p class="text-gray-500 mb-6">Try adjusting your filters or search query</p>
                    <a href="/treks" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold">
                        Clear Filters
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if (!empty($routes) && ($total_pages ?? 1) > 1): ?>
            <div class="mt-12 flex justify-center">
                <div class="flex space-x-2">
                    <?php if ($current_page > 1): ?>
                        <a href="?page=<?= $current_page - 1 ?>" class="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?= $i ?>" class="px-4 py-2 <?= $i === $current_page ? 'bg-blue-600 text-white' : 'bg-white border border-gray-300' ?> rounded-lg hover:bg-blue-700 hover:text-white">
                            <?= $i ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($current_page < $total_pages): ?>
                        <a href="?page=<?= $current_page + 1 ?>" class="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Call to Action -->
<section class="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-4">Can't Find What You're Looking For?</h2>
        <p class="text-xl mb-8">We can create a custom trek package just for you!</p>
        <a href="/contact" class="inline-block bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold transition">
            <i class="fas fa-envelope mr-2"></i> Get a Custom Quote
        </a>
    </div>
</section>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/frontend.php';
?>
