<?php
$pageTitle = 'Home';
$metaDescription = 'Experience authentic Himalayan adventures with Yeti Routes. Expert guides, small groups, fair prices. Trek Everest, Annapurna, Langtang and more.';
ob_start();
?>

<!-- Hero Section -->
<section class="relative w-full h-screen flex flex-col justify-center items-center text-center px-4">

    <!-- Background Video with Overlay -->
    <div class="absolute inset-0 w-full h-full -z-10 overflow-hidden">
        <div class="absolute inset-0 bg-black/20 z-10"></div>
        <video autoplay muted loop playsinline poster="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=2070" class="w-full h-full object-cover">
            <source src="https://videos.pexels.com/video-files/4125348/4125348-hd_1920_1080_25fps.mp4" type="video/mp4">
            <img src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=1920" alt="Himalayas">
        </video>
    </div>

    <!-- Hero Content -->
    <div class="relative z-20 flex flex-col items-center gap-10 mt-16 max-w-4xl mx-auto">

        <!-- Main Heading -->
        <h1 class="text-5xl md:text-7xl lg:text-8xl font-medium leading-[1.1] tracking-tight">
            Your Next Adventure <br> Starts Here
        </h1>

        <!-- CTA Buttons -->
        <div class="flex items-center gap-4">
            <a href="#featured-treks" class="bg-white text-black px-9 py-4 rounded-full font-medium text-lg hover:-translate-y-1 hover:shadow-lg transition transform duration-300">
                Book Your Trek
            </a>

            <a href="/contact" class="w-14 h-14 bg-brand-lime text-black rounded-full flex items-center justify-center text-xl hover:bg-[#bfff4f] hover:rotate-45 transition transform duration-300">
                <i class="ri-arrow-right-up-line"></i>
            </a>
        </div>

        <!-- Trip Finder Form -->
        <div id="hero-form-container" class="w-full max-w-2xl mt-8">
            <form action="/treks" method="GET" class="bg-black/30 backdrop-blur-md border border-white/10 rounded-3xl p-6">
                <h3 class="text-xl font-semibold mb-4">Find Your Perfect Trek</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <select name="region" class="px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white rounded-xl focus:ring-2 focus:ring-brand-lime focus:outline-none">
                        <option value="" class="text-gray-800">All Regions</option>
                        <option value="everest" class="text-gray-800">Everest Region</option>
                        <option value="annapurna" class="text-gray-800">Annapurna Region</option>
                        <option value="langtang" class="text-gray-800">Langtang Region</option>
                        <option value="manaslu" class="text-gray-800">Manaslu Region</option>
                    </select>

                    <select name="difficulty" class="px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white rounded-xl focus:ring-2 focus:ring-brand-lime focus:outline-none">
                        <option value="" class="text-gray-800">All Levels</option>
                        <option value="easy" class="text-gray-800">Easy</option>
                        <option value="moderate" class="text-gray-800">Moderate</option>
                        <option value="challenging" class="text-gray-800">Challenging</option>
                        <option value="extreme" class="text-gray-800">Extreme</option>
                    </select>
                </div>

                <button type="submit" class="group w-full bg-brand-lime text-black px-6 py-4 rounded-xl font-semibold text-lg hover:bg-[#bfff4f] transition duration-300 flex items-center justify-center gap-2">
                    <i class="ri-search-line"></i>
                    Search Treks
                    <i class="ri-arrow-right-line group-hover:translate-x-1 transition"></i>
                </button>
            </form>
        </div>

        <!-- Quick Stats -->
        <div class="mt-8 grid grid-cols-2 md:grid-cols-4 gap-8 text-white/90">
            <div class="text-center">
                <div class="text-4xl font-bold">1000+</div>
                <div class="text-sm text-white/70 mt-1">Happy Trekkers</div>
            </div>
            <div class="text-center">
                <div class="text-4xl font-bold">50+</div>
                <div class="text-sm text-white/70 mt-1">Trek Routes</div>
            </div>
            <div class="text-center">
                <div class="text-4xl font-bold">15+</div>
                <div class="text-sm text-white/70 mt-1">Expert Guides</div>
            </div>
            <div class="text-center">
                <div class="text-4xl font-bold">10</div>
                <div class="text-sm text-white/70 mt-1">Years Experience</div>
            </div>
        </div>
    </div>

    <!-- Scroll Down Indicator -->
    <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <i class="ri-arrow-down-s-line text-white text-3xl"></i>
    </div>
</section>

<!-- Lifelong Memories Section -->
<section class="relative py-24 bg-white overflow-hidden">
    <!-- Dotted Background Pattern -->
    <div class="absolute inset-0 opacity-10" style="background-image: radial-gradient(circle, #000 1px, transparent 1px); background-size: 20px 20px;"></div>

    <div class="container mx-auto px-4 relative z-10">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">

            <!-- Left Side - Image -->
            <div class="relative">
                <div class="relative rounded-3xl overflow-hidden shadow-2xl">
                    <img src="https://images.unsplash.com/photo-1501555088652-021faa106b9b?w=800"
                         alt="Trekker in the Himalayas"
                         class="w-full h-[600px] object-cover">

                    <!-- Floating Badge -->
                    <div class="absolute top-8 right-8 bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
                        <div class="flex items-center gap-3">
                            <div class="w-12 h-12 bg-brand-lime rounded-full flex items-center justify-center">
                                <i class="ri-star-fill text-black text-xl"></i>
                            </div>
                            <div>
                                <div class="text-2xl font-bold text-black">4.9/5</div>
                                <div class="text-sm text-gray-600">1000+ Reviews</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side - Content -->
            <div>
                <span class="text-brand-lime font-semibold text-lg">DISCOVER ADVENTURE</span>
                <h2 class="text-4xl md:text-5xl lg:text-6xl font-bold text-black mt-4 mb-6 leading-tight">
                    Lifelong Memories <br> Just A Few Days Away
                </h2>
                <p class="text-gray-600 text-lg mb-10 leading-relaxed">
                    Experience the thrill of the Himalayas with our expertly curated adventures. From challenging treks to serene nature walks, we offer unforgettable journeys that create memories to last a lifetime.
                </p>

                <!-- Activities Grid -->
                <div class="space-y-6">
                    <!-- Trekking -->
                    <div class="group flex items-start gap-6 bg-white/80 backdrop-blur-sm border border-gray-200 rounded-2xl p-6 hover:shadow-lg hover:border-brand-lime/50 transition duration-300">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-brand-lime/10 rounded-2xl flex items-center justify-center group-hover:bg-brand-lime/20 transition duration-300">
                                <i class="ri-mountain-line text-3xl text-brand-lime"></i>
                            </div>
                        </div>
                        <div class="flex-1">
                            <h3 class="text-xl font-bold text-black mb-2">Mountain Trekking</h3>
                            <p class="text-gray-600">Explore the majestic Himalayan trails with experienced guides. From beginner-friendly routes to challenging high-altitude expeditions.</p>
                        </div>
                    </div>

                    <!-- Rafting -->
                    <div class="group flex items-start gap-6 bg-white/80 backdrop-blur-sm border border-gray-200 rounded-2xl p-6 hover:shadow-lg hover:border-brand-lime/50 transition duration-300">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center group-hover:bg-blue-500/20 transition duration-300">
                                <i class="ri-water-flash-line text-3xl text-blue-500"></i>
                            </div>
                        </div>
                        <div class="flex-1">
                            <h3 class="text-xl font-bold text-black mb-2">River Rafting</h3>
                            <p class="text-gray-600">Navigate thrilling rapids on Nepal's pristine rivers. Perfect for adventure seekers looking for an adrenaline-pumping experience.</p>
                        </div>
                    </div>

                    <!-- Paragliding -->
                    <div class="group flex items-start gap-6 bg-white/80 backdrop-blur-sm border border-gray-200 rounded-2xl p-6 hover:shadow-lg hover:border-brand-lime/50 transition duration-300">
                        <div class="flex-shrink-0">
                            <div class="w-16 h-16 bg-purple-500/10 rounded-2xl flex items-center justify-center group-hover:bg-purple-500/20 transition duration-300">
                                <i class="ri-flight-takeoff-line text-3xl text-purple-500"></i>
                            </div>
                        </div>
                        <div class="flex-1">
                            <h3 class="text-xl font-bold text-black mb-2">Paragliding</h3>
                            <p class="text-gray-600">Soar above the clouds with breathtaking aerial views of the Himalayas. Experience the ultimate freedom of flight in Pokhara.</p>
                        </div>
                    </div>
                </div>

                <!-- CTA Button -->
                <div class="mt-10">
                    <a href="/treks" class="group inline-flex items-center gap-3 bg-black text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-gray-800 hover:-translate-y-1 transition transform duration-300">
                        Explore All Activities
                        <i class="ri-arrow-right-line group-hover:translate-x-1 transition"></i>
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- Dream Vacation Destination Section -->
<section class="relative py-24 bg-slate-900 text-white overflow-hidden">
    <!-- World Map Background -->
    <div class="absolute inset-0 opacity-5" style="background-image: url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 1200 800%22%3E%3Cpath fill=%22%23ffffff%22 d=%22M300,400 Q400,300 500,400 T700,400 Q800,500 900,400%22/%3E%3C/svg%3E'); background-size: cover; background-position: center;"></div>

    <div class="container mx-auto px-4 relative z-10">

        <!-- Section Header -->
        <div class="text-center mb-16">
            <span class="text-brand-lime font-semibold text-lg">EXPLORE THE HIMALAYAS</span>
            <h2 class="text-4xl md:text-5xl lg:text-6xl font-bold mt-4 mb-6">
                Dream Vacation Destination
            </h2>
            <p class="text-xl text-gray-400 max-w-3xl mx-auto">
                Discover Nepal's most iconic destinations. From ancient temples to pristine mountain peaks,
                experience the diversity of the Himalayas with our expertly crafted tour packages.
            </p>
        </div>

        <!-- Scrollable Carousel Wrapper -->
        <div class="relative mb-12">
            <!-- Navigation Buttons -->
            <button id="scroll-left" class="absolute -left-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-brand-lime text-black rounded-full flex items-center justify-center hover:bg-[#bfff4f] transition shadow-xl opacity-0 pointer-events-none lg:opacity-100 lg:pointer-events-auto">
                <i class="ri-arrow-left-s-line text-2xl"></i>
            </button>
            <button id="scroll-right" class="absolute -right-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-brand-lime text-black rounded-full flex items-center justify-center hover:bg-[#bfff4f] transition shadow-xl opacity-0 pointer-events-none lg:opacity-100 lg:pointer-events-auto">
                <i class="ri-arrow-right-s-line text-2xl"></i>
            </button>

            <!-- Scrollable Container -->
            <div id="trek-carousel" class="overflow-x-auto scrollbar-hide scroll-smooth pb-4" style="scrollbar-width: none; -ms-overflow-style: none;">
                <div class="flex gap-6 lg:gap-8" style="width: max-content;">

                    <?php if (isset($vacation_routes) && !empty($vacation_routes)): ?>
                        <?php foreach ($vacation_routes as $route): ?>
                            <!-- Trek Card -->
                            <div class="group relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl overflow-hidden hover:border-brand-lime/50 transition duration-500 flex-shrink-0 w-[280px] sm:w-[320px] lg:w-[340px]">
                                <div class="relative h-64 overflow-hidden">
                                    <?php
                                    // Fallback images based on location name
                                    $fallbackImages = [
                                        'everest' => 'photo-1506905925346-21bda4d32df4',
                                        'annapurna' => 'photo-1544735716-392fe2489ffa',
                                        'langtang' => 'photo-1519904981063-b0cf448d479e',
                                        'manaslu' => 'photo-1464822759023-fed622ff2c3b',
                                        'default' => 'photo-1506905925346-21bda4d32df4'
                                    ];

                                    $locationKey = strtolower($route->location_name ?? 'default');
                                    $imageId = $fallbackImages[$locationKey] ?? $fallbackImages['default'];
                                    $imageUrl = "https://images.unsplash.com/{$imageId}?w=600";
                                    ?>
                                    <img src="<?= htmlspecialchars($imageUrl) ?>"
                                         alt="<?= htmlspecialchars($route->title) ?>"
                                         class="w-full h-full object-cover group-hover:scale-110 transition duration-500">
                                    <div class="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>

                                    <!-- Price Badge -->
                                    <div class="absolute top-4 right-4 bg-brand-lime text-black px-4 py-2 rounded-full font-bold text-sm">
                                        From $<?= number_format($route->base_price ?? 0) ?>
                                    </div>
                                </div>

                                <div class="p-6">
                                    <div class="flex items-center gap-2 text-sm text-gray-400 mb-3">
                                        <i class="ri-map-pin-line"></i>
                                        <span><?= htmlspecialchars($route->location_name ?? 'Nepal') ?></span>
                                        <span class="mx-2">•</span>
                                        <i class="ri-time-line"></i>
                                        <span><?= htmlspecialchars($route->duration_days ?? 'N/A') ?> Days</span>
                                    </div>

                                    <h3 class="text-xl font-bold mb-3 group-hover:text-brand-lime transition line-clamp-2">
                                        <?= htmlspecialchars($route->title) ?>
                                    </h3>

                                    <p class="text-gray-400 mb-6 text-sm line-clamp-3">
                                        <?= htmlspecialchars($route->short_description ?? 'Discover the beauty of the Himalayas on this incredible trek.') ?>
                                    </p>

                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center gap-2 text-sm">
                                            <span class="px-3 py-1 bg-white/10 rounded-full text-xs font-medium">
                                                <?= ucfirst(htmlspecialchars($route->difficulty ?? 'Moderate')) ?>
                                            </span>
                                        </div>

                                        <a href="/trek?slug=<?= htmlspecialchars($route->slug) ?>"
                                           class="flex items-center gap-2 text-brand-lime font-semibold group-hover:gap-3 transition-all">
                                            View Details
                                            <i class="ri-arrow-right-line"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- Fallback message if no routes -->
                        <div class="w-full text-center py-12">
                            <p class="text-gray-400 text-lg">No treks available at the moment. Check back soon!</p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        <!-- Bottom CTA -->
        <div class="text-center">
            <a href="/treks" class="group inline-flex items-center gap-3 bg-brand-lime text-black px-10 py-5 rounded-full font-bold text-lg hover:bg-[#bfff4f] hover:-translate-y-1 transition transform duration-300 shadow-xl">
                View All Tour Packages
                <i class="ri-arrow-right-line group-hover:translate-x-1 transition"></i>
            </a>
        </div>

    </div>

    <!-- Scroll JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const carousel = document.getElementById('trek-carousel');
            const scrollLeft = document.getElementById('scroll-left');
            const scrollRight = document.getElementById('scroll-right');

            if (carousel && scrollLeft && scrollRight) {
                // Scroll amount (4 cards on desktop = ~1400px)
                const scrollAmount = window.innerWidth >= 1024 ? 1400 : 900;

                scrollRight.addEventListener('click', () => {
                    carousel.scrollBy({ left: scrollAmount, behavior: 'smooth' });
                });

                scrollLeft.addEventListener('click', () => {
                    carousel.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
                });

                // Update button visibility based on scroll position
                function updateButtons() {
                    const maxScroll = carousel.scrollWidth - carousel.clientWidth;

                    if (carousel.scrollLeft <= 0) {
                        scrollLeft.style.opacity = '0.5';
                        scrollLeft.style.pointerEvents = 'none';
                    } else {
                        scrollLeft.style.opacity = '1';
                        scrollLeft.style.pointerEvents = 'auto';
                    }

                    if (carousel.scrollLeft >= maxScroll - 10) {
                        scrollRight.style.opacity = '0.5';
                        scrollRight.style.pointerEvents = 'none';
                    } else {
                        scrollRight.style.opacity = '1';
                        scrollRight.style.pointerEvents = 'auto';
                    }
                }

                carousel.addEventListener('scroll', updateButtons);
                updateButtons(); // Initial check
            }
        });
    </script>

    <style>
        /* Hide scrollbar */
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }

        /* Smooth scroll snap on mobile */
        @media (max-width: 1023px) {
            #trek-carousel {
                scroll-snap-type: x mandatory;
            }
            #trek-carousel > div > div {
                scroll-snap-align: start;
            }
        }
    </style>
</section>

<!-- Why Yeti Routes -->
<section class="py-24 bg-slate-900 text-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold mb-4">Why Choose Yeti Routes?</h2>
            <p class="text-xl text-gray-400">Your trusted partner for authentic Himalayan experiences</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
            <div class="group bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center hover:bg-white/10 hover:border-brand-lime/50 transition duration-300">
                <div class="text-brand-lime text-5xl mb-4 group-hover:scale-110 transition duration-300">
                    <i class="ri-shield-check-line"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">Certified Guides</h3>
                <p class="text-gray-400">Government certified with 10+ years mountain experience</p>
            </div>

            <div class="group bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center hover:bg-white/10 hover:border-brand-lime/50 transition duration-300">
                <div class="text-brand-lime text-5xl mb-4 group-hover:scale-110 transition duration-300">
                    <i class="ri-first-aid-kit-line"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">Safety First</h3>
                <p class="text-gray-400">First aid trained, satellite phones, evacuation insurance</p>
            </div>

            <div class="group bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center hover:bg-white/10 hover:border-brand-lime/50 transition duration-300">
                <div class="text-brand-lime text-5xl mb-4 group-hover:scale-110 transition duration-300">
                    <i class="ri-team-line"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">Small Groups</h3>
                <p class="text-gray-400">Maximum 12 people for personalized attention</p>
            </div>

            <div class="group bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center hover:bg-white/10 hover:border-brand-lime/50 transition duration-300">
                <div class="text-brand-lime text-5xl mb-4 group-hover:scale-110 transition duration-300">
                    <i class="ri-heart-3-line"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">Local Experience</h3>
                <p class="text-gray-400">Authentic cultural immersion, support communities</p>
            </div>

            <div class="group bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center hover:bg-white/10 hover:border-brand-lime/50 transition duration-300">
                <div class="text-brand-lime text-5xl mb-4 group-hover:scale-110 transition duration-300">
                    <i class="ri-price-tag-3-line"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">Fair Pricing</h3>
                <p class="text-gray-400">Transparent pricing, no hidden costs, best value</p>
            </div>
        </div>
    </div>
</section>

<!-- Featured Treks -->
<section id="featured-treks" class="py-24 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold mb-4 text-slate-900">Featured Treks & Tours</h2>
            <p class="text-xl text-gray-600">Handpicked adventures for every type of traveler</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php if (!empty($featured_routes)): ?>
                <?php foreach ($featured_routes as $route): ?>
                    <div class="group bg-white rounded-2xl shadow-lg overflow-hidden hover:-translate-y-2 transition transform duration-300">
                        <div class="relative h-64 overflow-hidden">
                            <img src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600" alt="<?= htmlspecialchars($route->title) ?>" class="w-full h-full object-cover group-hover:scale-110 transition duration-300">
                            <div class="absolute top-4 right-4 bg-brand-lime text-black px-4 py-2 rounded-full text-sm font-semibold">
                                <i class="ri-star-fill"></i> Featured
                            </div>
                            <div class="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                                <div class="flex items-center justify-between text-white text-sm">
                                    <span><i class="ri-time-line mr-1"></i> <?= $route->duration_days ?> Days</span>
                                    <span><i class="ri-mountain-line mr-1"></i> <?= number_format($route->max_altitude_meters) ?>m</span>
                                </div>
                            </div>
                        </div>
                        <div class="p-6">
                            <h3 class="text-2xl font-bold mb-2 text-slate-900"><?= htmlspecialchars($route->title) ?></h3>
                            <p class="text-gray-600 mb-4 line-clamp-2"><?= htmlspecialchars($route->short_description) ?></p>

                            <div class="flex items-center justify-between mb-4">
                                <span class="px-3 py-1 rounded-full text-sm font-medium <?php
                                    echo match($route->difficulty) {
                                        'easy' => 'bg-green-100 text-green-800',
                                        'moderate' => 'bg-blue-100 text-blue-800',
                                        'challenging' => 'bg-orange-100 text-orange-800',
                                        'extreme' => 'bg-red-100 text-red-800',
                                        default => 'bg-gray-100 text-gray-800'
                                    };
                                ?>">
                                    <?= ucfirst($route->difficulty) ?>
                                </span>
                                <span class="text-2xl font-bold text-slate-900">
                                    $<?= number_format($route->base_price) ?>
                                </span>
                            </div>

                            <a href="/trek?slug=<?= htmlspecialchars($route->slug) ?>" class="group/btn flex items-center justify-center gap-2 w-full bg-slate-900 hover:bg-brand-lime text-white hover:text-black py-3 rounded-xl font-semibold transition duration-300">
                                View Details
                                <i class="ri-arrow-right-line group-hover/btn:translate-x-1 transition"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- Placeholder Trek Cards -->
                <?php for($i = 0; $i < 3; $i++): ?>
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="relative h-64 bg-gray-200 flex items-center justify-center">
                            <i class="ri-mountain-line text-6xl text-gray-400"></i>
                        </div>
                        <div class="p-6">
                            <h3 class="text-2xl font-bold mb-2 text-slate-900">Amazing Trek Coming Soon</h3>
                            <p class="text-gray-600 mb-4">Explore the stunning Himalayas with our expert guides...</p>
                            <div class="flex items-center justify-between mb-4">
                                <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">Moderate</span>
                                <span class="text-2xl font-bold text-slate-900">$1299</span>
                            </div>
                            <button disabled class="w-full bg-gray-300 text-gray-600 py-3 rounded-xl font-semibold cursor-not-allowed">
                                Coming Soon
                            </button>
                        </div>
                    </div>
                <?php endfor; ?>
            <?php endif; ?>
        </div>

        <div class="text-center mt-12">
            <a href="/treks" class="inline-flex items-center gap-2 bg-white border-2 border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white px-8 py-4 rounded-full text-lg font-semibold transition duration-300">
                View All Treks
                <i class="ri-arrow-right-line"></i>
            </a>
        </div>
    </div>
</section>

<!-- Destinations Section -->
<section class="py-24 bg-slate-900 text-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold mb-4">Explore by Region</h2>
            <p class="text-xl text-gray-400">Discover the diverse landscapes of the Himalayas</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php
            $regions = [
                ['name' => 'Everest Region', 'treks' => '15+ Treks', 'img' => 'photo-1506905925346-21bda4d32df4', 'url' => '/treks/everest'],
                ['name' => 'Annapurna Region', 'treks' => '20+ Treks', 'img' => 'photo-1544735716-392fe2489ffa', 'url' => '/treks/annapurna'],
                ['name' => 'Langtang Region', 'treks' => '10+ Treks', 'img' => 'photo-1486870591958-9b9d0d1dda99', 'url' => '/treks/langtang'],
                ['name' => 'Manaslu Region', 'treks' => '8+ Treks', 'img' => 'photo-1519904981063-b0cf448d479e', 'url' => '/treks/manaslu'],
            ];
            foreach ($regions as $region): ?>
                <a href="<?= $region['url'] ?>" class="group relative h-80 rounded-2xl overflow-hidden">
                    <img src="https://images.unsplash.com/<?= $region['img'] ?>?w=400" alt="<?= $region['name'] ?>" class="w-full h-full object-cover group-hover:scale-110 transition duration-500">
                    <div class="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                    <div class="absolute bottom-0 left-0 right-0 p-6">
                        <h3 class="text-2xl font-bold mb-2"><?= $region['name'] ?></h3>
                        <p class="text-gray-300 mb-4"><?= $region['treks'] ?> Available</p>
                        <div class="flex items-center gap-2 text-brand-lime font-semibold">
                            Explore Region
                            <i class="ri-arrow-right-line group-hover:translate-x-2 transition"></i>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="py-24 bg-white">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div class="relative">
                <img src="https://images.unsplash.com/photo-1519904981063-b0cf448d479e?w=800" alt="About Yeti Routes" class="rounded-3xl shadow-2xl">
                <div class="absolute -bottom-6 -right-6 bg-brand-lime text-black p-8 rounded-2xl shadow-xl">
                    <div class="text-4xl font-bold">10+</div>
                    <div class="font-semibold">Years of Excellence</div>
                </div>
            </div>
            <div>
                <h2 class="text-4xl md:text-5xl font-bold mb-6 text-slate-900">About Yeti Routes</h2>
                <p class="text-xl mb-6 leading-relaxed text-gray-700">
                    Born from a passion for the Himalayas, Yeti Routes connects adventurers with authentic Nepal experiences.
                    Our team of expert local guides brings decades of mountain knowledge and genuine hospitality.
                </p>
                <p class="text-lg mb-8 leading-relaxed text-gray-600">
                    We believe in responsible tourism, fair wages for our team, and creating memories that last a lifetime.
                    When you trek with us, you're not just a customer—you're family.
                </p>
                <a href="/about" class="inline-flex items-center gap-2 bg-slate-900 text-white hover:bg-brand-lime hover:text-black px-8 py-4 rounded-full font-semibold transition duration-300">
                    Learn More About Us
                    <i class="ri-arrow-right-line"></i>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-24 bg-slate-900 text-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold mb-4">Trusted by Travelers Worldwide</h2>
            <p class="text-xl text-gray-400">See what our trekkers say about their experiences</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div class="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center">
                <div class="text-yellow-400 text-6xl mb-4"><i class="ri-google-fill"></i></div>
                <div class="text-4xl font-bold mb-2">4.9/5</div>
                <div class="text-gray-400 mb-2">Based on 500+ reviews</div>
                <a href="#" class="text-brand-lime hover:underline">View Google Reviews →</a>
            </div>

            <div class="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center">
                <div class="text-green-400 text-6xl mb-4"><i class="ri-treasure-map-line"></i></div>
                <div class="text-4xl font-bold mb-2">5/5</div>
                <div class="text-gray-400 mb-2">Certificate of Excellence</div>
                <a href="#" class="text-brand-lime hover:underline">View TripAdvisor →</a>
            </div>

            <div class="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl text-center">
                <div class="text-brand-lime text-6xl mb-4"><i class="ri-award-line"></i></div>
                <div class="text-lg font-bold mb-2">Licensed & Certified</div>
                <div class="text-gray-400 mb-2">Nepal Tourism Board<br>License: 1234/075</div>
                <div class="text-sm text-gray-500">Member of TAAN & NMA</div>
            </div>
        </div>

        <!-- Customer Reviews -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php
            $reviews = [
                ['text' => 'Best trek of my life! The guides were knowledgeable, friendly, and always put safety first. Can\'t wait to come back!', 'name' => 'Sarah M.', 'country' => 'Australia', 'img' => 1],
                ['text' => 'Incredible experience! Small group, authentic local interactions, and fair pricing. Highly recommend Yeti Routes!', 'name' => 'John D.', 'country' => 'USA', 'img' => 12],
                ['text' => 'Professional, organized, and genuinely caring. The team went above and beyond to make our trek amazing!', 'name' => 'Emma L.', 'country' => 'UK', 'img' => 5],
            ];
            foreach ($reviews as $review): ?>
                <div class="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl">
                    <div class="flex items-center mb-4">
                        <div class="text-brand-lime text-xl">★★★★★</div>
                    </div>
                    <p class="text-gray-300 mb-6 leading-relaxed">"<?= $review['text'] ?>"</p>
                    <div class="flex items-center">
                        <img src="https://i.pravatar.cc/50?img=<?= $review['img'] ?>" alt="<?= $review['name'] ?>" class="w-12 h-12 rounded-full mr-3">
                        <div>
                            <div class="font-semibold"><?= $review['name'] ?></div>
                            <div class="text-sm text-gray-400"><?= $review['country'] ?></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Himalayan Gallery -->
<section class="py-24 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold mb-4 text-slate-900">Himalayan Gallery</h2>
            <p class="text-xl text-gray-600">Experience the beauty through our lens</p>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <?php
            $galleryImages = [
                'photo-1506905925346-21bda4d32df4',
                'photo-1544735716-392fe2489ffa',
                'photo-1486870591958-9b9d0d1dda99',
                'photo-1519904981063-b0cf448d479e',
                'photo-1549880338-65ddcdfd017b',
                'photo-1454496522488-7a8e488e8606',
                'photo-1464822759023-fed622ff2c3b',
                'photo-1506905925346-21bda4d32df4',
            ];
            foreach ($galleryImages as $img): ?>
                <div class="aspect-square overflow-hidden rounded-2xl group cursor-pointer">
                    <img src="https://images.unsplash.com/<?= $img ?>?w=400" alt="Gallery" class="w-full h-full object-cover group-hover:scale-110 transition duration-500">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Meet Our Guides -->
<section class="py-24 bg-slate-900 text-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold mb-4">Meet Our Expert Guides</h2>
            <p class="text-xl text-gray-400">The heart and soul of Yeti Routes</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php
            $guides = [
                ['name' => 'Pemba Sherpa', 'role' => 'Lead Guide', 'exp' => '15 years', 'img' => 1],
                ['name' => 'Lakpa Tamang', 'role' => 'Senior Guide', 'exp' => '12 years', 'img' => 13],
                ['name' => 'Dawa Lama', 'role' => 'Trek Leader', 'exp' => '10 years', 'img' => 14],
                ['name' => 'Mingma Sherpa', 'role' => 'Mountain Guide', 'exp' => '11 years', 'img' => 11],
            ];
            foreach ($guides as $guide): ?>
                <div class="group text-center">
                    <div class="relative mb-6">
                        <img src="https://i.pravatar.cc/200?img=<?= $guide['img'] ?>" alt="<?= $guide['name'] ?>" class="w-48 h-48 rounded-full mx-auto border-4 border-brand-lime group-hover:border-white transition duration-300">
                        <div class="absolute bottom-0 right-1/4 bg-brand-lime text-black w-12 h-12 rounded-full flex items-center justify-center font-bold">
                            <i class="ri-shield-check-fill text-xl"></i>
                        </div>
                    </div>
                    <h3 class="text-xl font-bold mb-1"><?= $guide['name'] ?></h3>
                    <p class="text-brand-lime mb-2 font-medium"><?= $guide['role'] ?></p>
                    <p class="text-gray-400"><i class="ri-mountain-line mr-2"></i><?= $guide['exp'] ?> experience</p>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-12">
            <a href="/guides" class="inline-flex items-center gap-2 bg-brand-lime text-black hover:bg-white px-8 py-4 rounded-full font-semibold transition duration-300">
                Meet the Full Team
                <i class="ri-arrow-right-line"></i>
            </a>
        </div>
    </div>
</section>

<!-- Final CTA Section -->
<section class="py-24 bg-brand-lime text-black">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-4xl md:text-6xl font-bold mb-6">Ready for Your Himalayan Adventure?</h2>
        <p class="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Let's plan the trek of a lifetime. Contact us today for a free consultation!
        </p>
        <div class="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/contact" class="inline-flex items-center gap-2 bg-black text-white hover:bg-slate-800 px-8 py-4 rounded-full text-lg font-semibold transition duration-300">
                <i class="ri-mail-line"></i>
                Contact Us
            </a>
            <a href="https://wa.me/9779841234567" class="inline-flex items-center gap-2 bg-white text-black hover:bg-slate-100 px-8 py-4 rounded-full text-lg font-semibold transition duration-300">
                <i class="ri-whatsapp-line"></i>
                Chat on WhatsApp
            </a>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/frontend.php';
?>
