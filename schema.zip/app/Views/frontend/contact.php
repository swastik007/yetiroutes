<?php
$pageTitle = 'Contact Us - Yeti Routes';
$metaDescription = 'Get in touch with Yeti Routes for trek bookings, custom itineraries, or any questions about trekking in Nepal.';
ob_start();
?>

<!-- Hero Section -->
<section class="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20">
    <div class="container mx-auto px-4">
        <div class="max-w-3xl mx-auto text-center">
            <h1 class="text-5xl font-bold mb-4">Get in Touch</h1>
            <p class="text-xl">We're here to help plan your perfect Himalayan adventure</p>
        </div>
    </div>
</section>

<!-- Contact Methods Grid -->
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <!-- Phone -->
            <div class="bg-white rounded-xl shadow-lg p-6 text-center hover-scale">
                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-phone text-blue-600 text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-2">Call Us</h3>
                <p class="text-gray-600 mb-2">24/7 Support</p>
                <a href="tel:+9779841234567" class="text-blue-600 font-semibold hover:underline">+977 984-1234567</a>
                <br>
                <a href="tel:+9779851234567" class="text-blue-600 font-semibold hover:underline">+977 985-1234567</a>
            </div>

            <!-- WhatsApp -->
            <div class="bg-white rounded-xl shadow-lg p-6 text-center hover-scale">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fab fa-whatsapp text-green-600 text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-2">WhatsApp</h3>
                <p class="text-gray-600 mb-2">Quick Response</p>
                <a href="https://wa.me/9779841234567?text=Hi%2C%20I%27m%20interested%20in%20trekking%20in%20Nepal" target="_blank" class="text-green-600 font-semibold hover:underline">Chat Now</a>
            </div>

            <!-- Email -->
            <div class="bg-white rounded-xl shadow-lg p-6 text-center hover-scale">
                <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-envelope text-purple-600 text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-2">Email Us</h3>
                <p class="text-gray-600 mb-2">Detailed Inquiries</p>
                <a href="mailto:info@yetiroutes.com" class="text-purple-600 font-semibold hover:underline">info@yetiroutes.com</a>
                <br>
                <a href="mailto:booking@yetiroutes.com" class="text-purple-600 font-semibold hover:underline">booking@yetiroutes.com</a>
            </div>

            <!-- Office -->
            <div class="bg-white rounded-xl shadow-lg p-6 text-center hover-scale">
                <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-map-marker-alt text-orange-600 text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-2">Visit Us</h3>
                <p class="text-gray-600 mb-2">Thamel, Kathmandu</p>
                <p class="text-sm text-gray-500">Mon-Sat: 9AM-6PM<br>Sunday: 10AM-4PM</p>
            </div>
        </div>

        <!-- Main Contact Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <!-- Contact Form -->
            <div class="bg-white rounded-xl shadow-lg p-8">
                <h2 class="text-3xl font-bold mb-6">Send Us a Message</h2>
                <form id="contactForm" method="POST" action="/contact/submit">
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 font-semibold mb-2">Full Name *</label>
                        <input type="text" id="name" name="name" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <div class="mb-4">
                        <label for="email" class="block text-gray-700 font-semibold mb-2">Email Address *</label>
                        <input type="email" id="email" name="email" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <div class="mb-4">
                        <label for="phone" class="block text-gray-700 font-semibold mb-2">Phone Number</label>
                        <input type="tel" id="phone" name="phone" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <div class="mb-4">
                        <label for="nationality" class="block text-gray-700 font-semibold mb-2">Nationality</label>
                        <input type="text" id="nationality" name="nationality" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <div class="mb-4">
                        <label for="trek_interest" class="block text-gray-700 font-semibold mb-2">Trek of Interest</label>
                        <select id="trek_interest" name="trek_interest" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <option value="">Select a trek (optional)</option>
                            <option value="everest-base-camp">Everest Base Camp Trek</option>
                            <option value="annapurna-circuit">Annapurna Circuit</option>
                            <option value="langtang-valley">Langtang Valley Trek</option>
                            <option value="manaslu-circuit">Manaslu Circuit</option>
                            <option value="custom">Custom Trek Package</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label for="travel_date" class="block text-gray-700 font-semibold mb-2">Preferred Travel Date</label>
                        <input type="date" id="travel_date" name="travel_date" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <div class="mb-4">
                        <label for="group_size" class="block text-gray-700 font-semibold mb-2">Group Size</label>
                        <select id="group_size" name="group_size" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <option value="">Select group size</option>
                            <option value="solo">Solo Traveler</option>
                            <option value="2">2 People</option>
                            <option value="3-5">3-5 People</option>
                            <option value="6-10">6-10 People</option>
                            <option value="10+">More than 10</option>
                        </select>
                    </div>

                    <div class="mb-6">
                        <label for="message" class="block text-gray-700 font-semibold mb-2">Your Message *</label>
                        <textarea id="message" name="message" rows="5" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Tell us about your trekking plans, questions, or special requirements..."></textarea>
                    </div>

                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-lg font-semibold text-lg transition">
                        <i class="fas fa-paper-plane mr-2"></i> Send Message
                    </button>
                </form>

                <div id="formMessage" class="mt-4 hidden"></div>
            </div>

            <!-- Office Information -->
            <div>
                <!-- Office Location -->
                <div class="bg-white rounded-xl shadow-lg p-8 mb-8">
                    <h2 class="text-3xl font-bold mb-6">Our Office</h2>

                    <div class="mb-6">
                        <div class="flex items-start mb-4">
                            <i class="fas fa-map-marker-alt text-blue-600 text-xl mr-4 mt-1"></i>
                            <div>
                                <h3 class="font-bold text-lg mb-1">Address</h3>
                                <p class="text-gray-600">Tridevi Marg, Thamel<br>Kathmandu 44600, Nepal</p>
                            </div>
                        </div>

                        <div class="flex items-start mb-4">
                            <i class="fas fa-clock text-blue-600 text-xl mr-4 mt-1"></i>
                            <div>
                                <h3 class="font-bold text-lg mb-1">Office Hours</h3>
                                <p class="text-gray-600">
                                    Monday - Friday: 9:00 AM - 6:00 PM<br>
                                    Saturday: 10:00 AM - 5:00 PM<br>
                                    Sunday: 10:00 AM - 4:00 PM
                                </p>
                            </div>
                        </div>

                        <div class="flex items-start">
                            <i class="fas fa-headset text-blue-600 text-xl mr-4 mt-1"></i>
                            <div>
                                <h3 class="font-bold text-lg mb-1">Emergency Contact</h3>
                                <p class="text-gray-600">24/7 Support Available<br>+977 984-1234567</p>
                            </div>
                        </div>
                    </div>

                    <!-- Map Embed -->
                    <div class="rounded-lg overflow-hidden h-64 bg-gray-200">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3532.0346347347867!2d85.3105307!3d27.7147096!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb18fdefffffff%3A0x5f00498ab691fed8!2sThamel%2C%20Kathmandu%2044600!5e0!3m2!1sen!2snp!4v1234567890"
                            width="100%"
                            height="100%"
                            style="border:0;"
                            allowfullscreen=""
                            loading="lazy">
                        </iframe>
                    </div>
                </div>

                <!-- Quick Response Promise -->
                <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl shadow-lg p-8">
                    <h3 class="text-2xl font-bold mb-4">Quick Response Guarantee</h3>
                    <ul class="space-y-3">
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-green-300 mr-3"></i>
                            <span>Response within 24 hours</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-green-300 mr-3"></i>
                            <span>Free custom itinerary planning</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-green-300 mr-3"></i>
                            <span>No obligation quotes</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-green-300 mr-3"></i>
                            <span>Expert trek recommendations</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-12">Frequently Asked Questions</h2>

            <div class="space-y-4">
                <div class="border border-gray-200 rounded-lg">
                    <button class="faq-toggle w-full px-6 py-4 text-left font-semibold text-lg flex items-center justify-between hover:bg-gray-50">
                        <span>How do I book a trek?</span>
                        <i class="fas fa-chevron-down transition-transform"></i>
                    </button>
                    <div class="faq-content hidden px-6 pb-4 text-gray-600">
                        <p>You can book a trek by filling out the contact form above, sending us an email, or contacting us via WhatsApp. We'll send you a detailed itinerary and quote within 24 hours. Once you confirm, we require a 25% deposit to secure your booking.</p>
                    </div>
                </div>

                <div class="border border-gray-200 rounded-lg">
                    <button class="faq-toggle w-full px-6 py-4 text-left font-semibold text-lg flex items-center justify-between hover:bg-gray-50">
                        <span>How quickly will I get a response?</span>
                        <i class="fas fa-chevron-down transition-transform"></i>
                    </button>
                    <div class="faq-content hidden px-6 pb-4 text-gray-600">
                        <p>We typically respond to all inquiries within 24 hours during business days. For urgent matters, please contact us via WhatsApp (+977 984-1234567) for immediate assistance.</p>
                    </div>
                </div>

                <div class="border border-gray-200 rounded-lg">
                    <button class="faq-toggle w-full px-6 py-4 text-left font-semibold text-lg flex items-center justify-between hover:bg-gray-50">
                        <span>Can you create custom itineraries?</span>
                        <i class="fas fa-chevron-down transition-transform"></i>
                    </button>
                    <div class="faq-content hidden px-6 pb-4 text-gray-600">
                        <p>Absolutely! We specialize in creating custom trek itineraries based on your interests, fitness level, available time, and budget. Just let us know your preferences in the contact form or via email.</p>
                    </div>
                </div>

                <div class="border border-gray-200 rounded-lg">
                    <button class="faq-toggle w-full px-6 py-4 text-left font-semibold text-lg flex items-center justify-between hover:bg-gray-50">
                        <span>Do you offer airport pickup?</span>
                        <i class="fas fa-chevron-down transition-transform"></i>
                    </button>
                    <div class="faq-content hidden px-6 pb-4 text-gray-600">
                        <p>Yes! Complimentary airport pickup and drop-off are included in all our trek packages. Just provide your flight details when booking, and our representative will be there to greet you.</p>
                    </div>
                </div>

                <div class="border border-gray-200 rounded-lg">
                    <button class="faq-toggle w-full px-6 py-4 text-left font-semibold text-lg flex items-center justify-between hover:bg-gray-50">
                        <span>What's your cancellation policy?</span>
                        <i class="fas fa-chevron-down transition-transform"></i>
                    </button>
                    <div class="faq-content hidden px-6 pb-4 text-gray-600">
                        <p>We offer flexible cancellation with full refund (minus processing fees) for cancellations made 30+ days before departure. For detailed terms, please visit our <a href="/cancellation-policy" class="text-blue-600 hover:underline">Cancellation Policy</a> page.</p>
                    </div>
                </div>

                <div class="border border-gray-200 rounded-lg">
                    <button class="faq-toggle w-full px-6 py-4 text-left font-semibold text-lg flex items-center justify-between hover:bg-gray-50">
                        <span>Can I visit your office in person?</span>
                        <i class="fas fa-chevron-down transition-transform"></i>
                    </button>
                    <div class="faq-content hidden px-6 pb-4 text-gray-600">
                        <p>Yes! We welcome visitors to our office in Thamel, Kathmandu. Please check our office hours above, or contact us beforehand to schedule a meeting with one of our trek specialists.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Social Media Section -->
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-4">Follow Our Adventures</h2>
        <p class="text-gray-600 mb-8">Stay connected and see our latest treks, tips, and Himalayan stories</p>

        <div class="flex justify-center space-x-6 mb-8">
            <a href="https://facebook.com/yetiroutes" target="_blank" class="w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center text-2xl transition">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="https://instagram.com/yetiroutes" target="_blank" class="w-14 h-14 bg-pink-600 hover:bg-pink-700 text-white rounded-full flex items-center justify-center text-2xl transition">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="https://twitter.com/yetiroutes" target="_blank" class="w-14 h-14 bg-blue-400 hover:bg-blue-500 text-white rounded-full flex items-center justify-center text-2xl transition">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="https://youtube.com/yetiroutes" target="_blank" class="w-14 h-14 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center text-2xl transition">
                <i class="fab fa-youtube"></i>
            </a>
            <a href="https://tripadvisor.com/yetiroutes" target="_blank" class="w-14 h-14 bg-green-600 hover:bg-green-700 text-white rounded-full flex items-center justify-center text-2xl transition">
                <i class="fab fa-tripadvisor"></i>
            </a>
        </div>
    </div>
</section>

<script>
// FAQ Accordion
document.querySelectorAll('.faq-toggle').forEach(button => {
    button.addEventListener('click', () => {
        const content = button.nextElementSibling;
        const icon = button.querySelector('i');

        // Close all other FAQs
        document.querySelectorAll('.faq-content').forEach(item => {
            if (item !== content) {
                item.classList.add('hidden');
                item.previousElementSibling.querySelector('i').style.transform = 'rotate(0deg)';
            }
        });

        // Toggle current FAQ
        content.classList.toggle('hidden');
        icon.style.transform = content.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(180deg)';
    });
});

// Form Submission (AJAX)
document.getElementById('contactForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const messageDiv = document.getElementById('formMessage');

    try {
        const response = await fetch('/contact/submit', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            messageDiv.className = 'mt-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded';
            messageDiv.textContent = 'Thank you! We\'ll get back to you within 24 hours.';
            e.target.reset();
        } else {
            messageDiv.className = 'mt-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded';
            messageDiv.textContent = result.message || 'Something went wrong. Please try again.';
        }

        messageDiv.classList.remove('hidden');

        // Scroll to message
        messageDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    } catch (error) {
        messageDiv.className = 'mt-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded';
        messageDiv.textContent = 'Error submitting form. Please try WhatsApp or email instead.';
        messageDiv.classList.remove('hidden');
    }
});
</script>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/frontend.php';
?>
