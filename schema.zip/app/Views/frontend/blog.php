<?php
$pageTitle = 'Travel Blog - Nepal Trekking Stories & Tips';
$metaDescription = 'Read inspiring trekking stories, travel tips, and guides for exploring Nepal and the Himalayas.';
ob_start();
?>

<!-- Hero Section -->
<section class="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20">
    <div class="container mx-auto px-4">
        <div class="max-w-3xl mx-auto text-center">
            <h1 class="text-5xl font-bold mb-4">Travel Blog</h1>
            <p class="text-xl">Stories, tips, and guides from the Himalayas</p>
        </div>
    </div>
</section>

<!-- Categories Filter -->
<section class="bg-white shadow-md sticky top-16 z-40">
    <div class="container mx-auto px-4 py-4">
        <div class="flex flex-wrap gap-3">
            <a href="/blog" class="px-4 py-2 rounded-full <?= empty($_GET['category']) ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                All Posts
            </a>
            <a href="/blog?category=trekking-guides" class="px-4 py-2 rounded-full <?= ($_GET['category'] ?? '') === 'trekking-guides' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                <i class="fas fa-hiking mr-1"></i> Trekking Guides
            </a>
            <a href="/blog?category=trip-reports" class="px-4 py-2 rounded-full <?= ($_GET['category'] ?? '') === 'trip-reports' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                <i class="fas fa-book-open mr-1"></i> Trip Reports
            </a>
            <a href="/blog?category=travel-tips" class="px-4 py-2 rounded-full <?= ($_GET['category'] ?? '') === 'travel-tips' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                <i class="fas fa-lightbulb mr-1"></i> Travel Tips
            </a>
            <a href="/blog?category=culture" class="px-4 py-2 rounded-full <?= ($_GET['category'] ?? '') === 'culture' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                <i class="fas fa-globe mr-1"></i> Culture & People
            </a>
            <a href="/blog?category=gear-reviews" class="px-4 py-2 rounded-full <?= ($_GET['category'] ?? '') === 'gear-reviews' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                <i class="fas fa-backpack mr-1"></i> Gear Reviews
            </a>
        </div>
    </div>
</section>

<!-- Main Content -->
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

            <!-- Blog Posts (Left - 2/3) -->
            <div class="lg:col-span-2">
                <?php if (!empty($posts)): ?>
                    <!-- Featured Post (First Post if exists) -->
                    <?php if (isset($posts[0]) && $current_page === 1):
                        $featured = $posts[0];
                    ?>
                        <article class="bg-white rounded-xl shadow-lg overflow-hidden mb-8 hover-scale">
                            <div class="relative h-96">
                                <img src="<?= $featured->featured_image ?? 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800' ?>" alt="<?= htmlspecialchars($featured->title) ?>" class="w-full h-full object-cover">
                                <div class="absolute top-4 left-4">
                                    <span class="bg-yellow-500 text-white px-4 py-2 rounded-full font-semibold text-sm">
                                        <i class="fas fa-star mr-1"></i> Featured
                                    </span>
                                </div>
                            </div>
                            <div class="p-8">
                                <div class="flex items-center text-sm text-gray-500 mb-3">
                                    <span class="mr-4">
                                        <i class="fas fa-calendar mr-1"></i>
                                        <?= date('M d, Y', strtotime($featured->published_at ?? $featured->created_at)) ?>
                                    </span>
                                    <span class="mr-4">
                                        <i class="fas fa-user mr-1"></i>
                                        <?= htmlspecialchars($featured->author_name ?? 'Yeti Routes') ?>
                                    </span>
                                    <span class="mr-4">
                                        <i class="fas fa-clock mr-1"></i>
                                        <?= $featured->read_time ?? 5 ?> min read
                                    </span>
                                </div>

                                <h2 class="text-3xl font-bold mb-4 hover:text-blue-600">
                                    <a href="/blog/<?= htmlspecialchars($featured->slug) ?>"><?= htmlspecialchars($featured->title) ?></a>
                                </h2>

                                <p class="text-gray-600 text-lg mb-4 line-clamp-3"><?= htmlspecialchars($featured->excerpt ?? $featured->meta_description) ?></p>

                                <div class="flex items-center justify-between">
                                    <div class="flex flex-wrap gap-2">
                                        <?php if (!empty($featured->tags)):
                                            $tags = is_string($featured->tags) ? json_decode($featured->tags, true) : $featured->tags;
                                            foreach (array_slice($tags ?? [], 0, 3) as $tag):
                                        ?>
                                            <span class="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs"><?= htmlspecialchars($tag) ?></span>
                                        <?php endforeach; endif; ?>
                                    </div>
                                    <a href="/blog/<?= htmlspecialchars($featured->slug) ?>" class="text-blue-600 hover:text-blue-800 font-semibold">
                                        Read More <i class="fas fa-arrow-right ml-1"></i>
                                    </a>
                                </div>
                            </div>
                        </article>
                    <?php endif; ?>

                    <!-- Regular Posts Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <?php
                        $startIndex = ($current_page === 1 && isset($posts[0])) ? 1 : 0;
                        for ($i = $startIndex; $i < count($posts); $i++):
                            $post = $posts[$i];
                        ?>
                            <article class="bg-white rounded-xl shadow-lg overflow-hidden hover-scale">
                                <div class="relative h-48">
                                    <img src="<?= $post->featured_image ?? 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600' ?>" alt="<?= htmlspecialchars($post->title) ?>" class="w-full h-full object-cover">
                                    <?php if ($post->category): ?>
                                        <div class="absolute top-3 left-3">
                                            <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                                                <?= ucfirst(str_replace('-', ' ', $post->category)) ?>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="p-6">
                                    <div class="flex items-center text-xs text-gray-500 mb-2">
                                        <span class="mr-3">
                                            <i class="fas fa-calendar mr-1"></i>
                                            <?= date('M d, Y', strtotime($post->published_at ?? $post->created_at)) ?>
                                        </span>
                                        <span>
                                            <i class="fas fa-clock mr-1"></i>
                                            <?= $post->read_time ?? 5 ?> min
                                        </span>
                                    </div>

                                    <h3 class="text-xl font-bold mb-3 hover:text-blue-600 line-clamp-2">
                                        <a href="/blog/<?= htmlspecialchars($post->slug) ?>"><?= htmlspecialchars($post->title) ?></a>
                                    </h3>

                                    <p class="text-gray-600 text-sm mb-4 line-clamp-3"><?= htmlspecialchars($post->excerpt ?? $post->meta_description) ?></p>

                                    <a href="/blog/<?= htmlspecialchars($post->slug) ?>" class="text-blue-600 hover:text-blue-800 font-semibold text-sm">
                                        Read More <i class="fas fa-arrow-right ml-1"></i>
                                    </a>
                                </div>
                            </article>
                        <?php endfor; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if (($total_pages ?? 1) > 1): ?>
                        <div class="mt-12 flex justify-center">
                            <div class="flex space-x-2">
                                <?php if ($current_page > 1): ?>
                                    <a href="?page=<?= $current_page - 1 ?><?= !empty($_GET['category']) ? '&category=' . $_GET['category'] : '' ?>" class="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                                        <i class="fas fa-chevron-left"></i> Previous
                                    </a>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <a href="?page=<?= $i ?><?= !empty($_GET['category']) ? '&category=' . $_GET['category'] : '' ?>" class="px-4 py-2 <?= $i === $current_page ? 'bg-blue-600 text-white' : 'bg-white border border-gray-300' ?> rounded-lg hover:bg-blue-700 hover:text-white">
                                        <?= $i ?>
                                    </a>
                                <?php endfor; ?>

                                <?php if ($current_page < $total_pages): ?>
                                    <a href="?page=<?= $current_page + 1 ?><?= !empty($_GET['category']) ? '&category=' . $_GET['category'] : '' ?>" class="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                                        Next <i class="fas fa-chevron-right"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <!-- No Posts Found -->
                    <div class="bg-white rounded-xl shadow-lg p-16 text-center">
                        <i class="fas fa-book-open text-6xl text-gray-300 mb-4"></i>
                        <h3 class="text-2xl font-bold text-gray-600 mb-2">No Posts Found</h3>
                        <p class="text-gray-500 mb-6">Check back soon for new content!</p>
                        <a href="/blog" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold">
                            View All Posts
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar (Right - 1/3) -->
            <div class="lg:col-span-1">
                <!-- Search -->
                <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
                    <h3 class="text-xl font-bold mb-4">Search Blog</h3>
                    <form method="GET" action="/blog">
                        <div class="relative">
                            <input type="text" name="search" placeholder="Search articles..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" class="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <button type="submit" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-blue-600">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Popular Posts -->
                <?php if (!empty($popular_posts)): ?>
                    <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
                        <h3 class="text-xl font-bold mb-4">Popular Posts</h3>
                        <div class="space-y-4">
                            <?php foreach ($popular_posts as $popular): ?>
                                <a href="/blog/<?= htmlspecialchars($popular->slug) ?>" class="flex items-start group">
                                    <img src="<?= $popular->featured_image ?? 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=200' ?>" alt="<?= htmlspecialchars($popular->title) ?>" class="w-20 h-20 object-cover rounded-lg mr-3 flex-shrink-0">
                                    <div>
                                        <h4 class="font-semibold text-sm group-hover:text-blue-600 line-clamp-2 mb-1"><?= htmlspecialchars($popular->title) ?></h4>
                                        <p class="text-xs text-gray-500">
                                            <i class="fas fa-calendar mr-1"></i>
                                            <?= date('M d, Y', strtotime($popular->published_at ?? $popular->created_at)) ?>
                                        </p>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Categories -->
                <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
                    <h3 class="text-xl font-bold mb-4">Categories</h3>
                    <div class="space-y-2">
                        <?php
                        $categories = [
                            'trekking-guides' => ['name' => 'Trekking Guides', 'icon' => 'fa-hiking', 'count' => $category_counts['trekking-guides'] ?? 0],
                            'trip-reports' => ['name' => 'Trip Reports', 'icon' => 'fa-book-open', 'count' => $category_counts['trip-reports'] ?? 0],
                            'travel-tips' => ['name' => 'Travel Tips', 'icon' => 'fa-lightbulb', 'count' => $category_counts['travel-tips'] ?? 0],
                            'culture' => ['name' => 'Culture & People', 'icon' => 'fa-globe', 'count' => $category_counts['culture'] ?? 0],
                            'gear-reviews' => ['name' => 'Gear Reviews', 'icon' => 'fa-backpack', 'count' => $category_counts['gear-reviews'] ?? 0],
                        ];
                        foreach ($categories as $slug => $cat):
                        ?>
                            <a href="/blog?category=<?= $slug ?>" class="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition">
                                <span>
                                    <i class="fas <?= $cat['icon'] ?> text-blue-600 mr-2"></i>
                                    <?= $cat['name'] ?>
                                </span>
                                <span class="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs"><?= $cat['count'] ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Tags Cloud -->
                <?php if (!empty($popular_tags)): ?>
                    <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
                        <h3 class="text-xl font-bold mb-4">Popular Tags</h3>
                        <div class="flex flex-wrap gap-2">
                            <?php foreach ($popular_tags as $tag): ?>
                                <a href="/blog?search=<?= urlencode($tag) ?>" class="bg-gray-100 hover:bg-blue-100 text-gray-700 hover:text-blue-600 px-3 py-1 rounded-full text-sm transition">
                                    #<?= htmlspecialchars($tag) ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Newsletter Signup -->
                <div class="bg-gradient-to-br from-blue-600 to-purple-600 text-white rounded-xl shadow-lg p-6">
                    <h3 class="text-xl font-bold mb-2">Get Travel Updates</h3>
                    <p class="text-sm mb-4 opacity-90">Subscribe to our newsletter for trekking tips and special offers</p>
                    <form method="POST" action="/newsletter/subscribe" id="newsletterForm">
                        <input type="email" name="email" placeholder="Your email" required class="w-full px-4 py-3 rounded-lg mb-3 text-gray-800">
                        <button type="submit" class="w-full bg-white text-blue-600 hover:bg-gray-100 py-3 rounded-lg font-semibold transition">
                            <i class="fas fa-envelope mr-2"></i> Subscribe
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-4">Ready to Start Your Himalayan Adventure?</h2>
        <p class="text-xl mb-8">Browse our trek packages or get in touch for a custom itinerary</p>
        <div class="flex flex-wrap justify-center gap-4">
            <a href="/treks" class="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fas fa-mountain mr-2"></i> Explore Treks
            </a>
            <a href="/contact" class="bg-transparent border-2 border-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fas fa-envelope mr-2"></i> Contact Us
            </a>
        </div>
    </div>
</section>

<script>
// Newsletter form submission
document.getElementById('newsletterForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
        const response = await fetch('/newsletter/subscribe', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            alert('Thank you for subscribing! Check your email for confirmation.');
            e.target.reset();
        } else {
            alert(result.message || 'Subscription failed. Please try again.');
        }
    } catch (error) {
        alert('Error submitting form. Please try again later.');
    }
});
</script>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/frontend.php';
?>
