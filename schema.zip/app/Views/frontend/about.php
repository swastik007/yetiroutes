<?php
$pageTitle = 'About Us - Our Story';
$metaDescription = 'Learn about Yeti Routes - Your trusted partner for authentic Himalayan adventures. Our story, mission, and commitment to responsible tourism.';
ob_start();
?>

<!-- Hero Section -->
<section class="relative h-96 overflow-hidden">
    <img src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=1920" alt="About Yeti Routes" class="w-full h-full object-cover">
    <div class="absolute inset-0 bg-black bg-opacity-60 flex items-center">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-5xl md:text-6xl font-bold text-white mb-4">Our Story</h1>
            <p class="text-xl text-gray-200 max-w-2xl mx-auto">Born from a passion for the Himalayas, built on trust and experience</p>
        </div>
    </div>
</section>

<!-- Our Story -->
<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-4xl font-bold mb-8 text-center">Welcome to Yeti Routes</h2>

            <div class="prose prose-lg max-w-none mb-12">
                <p class="text-xl text-gray-700 leading-relaxed mb-6">
                    Yeti Routes was born from a simple dream: to share the breathtaking beauty and rich culture of the Himalayas with travelers from around the world, while maintaining the highest standards of safety, authenticity, and respect for local communities.
                </p>

                <p class="text-lg text-gray-700 leading-relaxed mb-6">
                    Founded in 2014 by a team of experienced mountain guides and travel enthusiasts, we've grown from a small local operation to one of Nepal's most trusted trekking companies. But despite our growth, we've never lost sight of what makes us special: personal attention, deep local knowledge, and genuine care for every trekker who joins us.
                </p>

                <p class="text-lg text-gray-700 leading-relaxed">
                    Today, we've successfully guided over 1,000 trekkers from 50+ countries to the roof of the world. Each journey is more than just a trek—it's a transformation, a connection with nature, culture, and oneself.
                </p>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center mb-12">
                <div class="p-6 bg-blue-50 rounded-xl">
                    <div class="text-4xl font-bold text-blue-600 mb-2">2014</div>
                    <div class="text-gray-600">Founded</div>
                </div>
                <div class="p-6 bg-green-50 rounded-xl">
                    <div class="text-4xl font-bold text-green-600 mb-2">1000+</div>
                    <div class="text-gray-600">Happy Trekkers</div>
                </div>
                <div class="p-6 bg-purple-50 rounded-xl">
                    <div class="text-4xl font-bold text-purple-600 mb-2">50+</div>
                    <div class="text-gray-600">Countries</div>
                </div>
                <div class="p-6 bg-orange-50 rounded-xl">
                    <div class="text-4xl font-bold text-orange-600 mb-2">15</div>
                    <div class="text-gray-600">Expert Guides</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision -->
<section class="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            <div class="bg-white bg-opacity-10 p-8 rounded-xl backdrop-blur">
                <div class="text-5xl mb-4"><i class="fas fa-bullseye"></i></div>
                <h3 class="text-3xl font-bold mb-4">Our Mission</h3>
                <p class="text-lg leading-relaxed">
                    To provide authentic, safe, and transformative Himalayan experiences that respect local culture, support communities, and create lasting memories while maintaining the highest standards of service and environmental responsibility.
                </p>
            </div>
            <div class="bg-white bg-opacity-10 p-8 rounded-xl backdrop-blur">
                <div class="text-5xl mb-4"><i class="fas fa-eye"></i></div>
                <h3 class="text-3xl font-bold mb-4">Our Vision</h3>
                <p class="text-lg leading-relaxed">
                    To be the most trusted and respected trekking company in Nepal, known for our commitment to safety, sustainability, and creating meaningful connections between travelers and the Himalayan people and culture.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Why Choose Yeti Routes -->
<section class="py-20 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold mb-4">Why Choose Yeti Routes?</h2>
            <p class="text-xl text-gray-600">What makes us different from other trekking companies</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div class="bg-white p-8 rounded-xl shadow-lg">
                <div class="text-blue-600 text-5xl mb-4"><i class="fas fa-certificate"></i></div>
                <h3 class="text-2xl font-bold mb-4">Certified Excellence</h3>
                <p class="text-gray-700 mb-4">All our guides are government-certified with minimum 10 years of mountain experience. We hold licenses from Nepal Tourism Board, and are proud members of TAAN and NMA.</p>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li><i class="fas fa-check text-green-600 mr-2"></i>Nepal Tourism Board Licensed</li>
                    <li><i class="fas fa-check text-green-600 mr-2"></i>TAAN Member</li>
                    <li><i class="fas fa-check text-green-600 mr-2"></i>NMA Certified</li>
                </ul>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-lg">
                <div class="text-green-600 text-5xl mb-4"><i class="fas fa-shield-alt"></i></div>
                <h3 class="text-2xl font-bold mb-4">Safety First Always</h3>
                <p class="text-gray-700 mb-4">Your safety is our top priority. We carry comprehensive medical kits, satellite phones, and have partnerships with helicopter rescue services.</p>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li><i class="fas fa-check text-green-600 mr-2"></i>First Aid Certified Guides</li>
                    <li><i class="fas fa-check text-green-600 mr-2"></i>Emergency Evacuation Insurance</li>
                    <li><i class="fas fa-check text-green-600 mr-2"></i>24/7 Support Team</li>
                </ul>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-lg">
                <div class="text-purple-600 text-5xl mb-4"><i class="fas fa-heart"></i></div>
                <h3 class="text-2xl font-bold mb-4">Responsible Tourism</h3>
                <p class="text-gray-700 mb-4">We believe in giving back. Fair wages for our team, support for local communities, and commitment to environmental conservation.</p>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li><i class="fas fa-check text-green-600 mr-2"></i>Fair Wages & Insurance</li>
                    <li><i class="fas fa-check text-green-600 mr-2"></i>Community Support Projects</li>
                    <li><i class="fas fa-check text-green-600 mr-2"></i>Zero Waste Initiatives</li>
                </ul>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-lg">
                <div class="text-orange-600 text-5xl mb-4"><i class="fas fa-users"></i></div>
                <h3 class="text-2xl font-bold mb-4">Small Group Sizes</h3>
                <p class="text-gray-700">Maximum 12 people per group ensures personalized attention, flexibility, and authentic local interactions that large groups simply can't provide.</p>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-lg">
                <div class="text-red-600 text-5xl mb-4"><i class="fas fa-hand-holding-usd"></i></div>
                <h3 class="text-2xl font-bold mb-4">Transparent Pricing</h3>
                <p class="text-gray-700">No hidden costs, no surprises. What you see is what you pay. We provide detailed cost breakdowns and offer the best value for money in the industry.</p>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-lg">
                <div class="text-indigo-600 text-5xl mb-4"><i class="fas fa-headset"></i></div>
                <h3 class="text-2xl font-bold mb-4">24/7 Support</h3>
                <p class="text-gray-700">From your first inquiry to your safe return home, our support team is available round-the-clock via phone, email, and WhatsApp.</p>
            </div>
        </div>
    </div>
</section>

<!-- Our Values -->
<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-4xl font-bold mb-12 text-center">Our Core Values</h2>

            <div class="space-y-8">
                <div class="flex items-start">
                    <div class="flex-shrink-0 w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mr-6">
                        <i class="fas fa-thumbs-up text-blue-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold mb-2">Integrity</h3>
                        <p class="text-gray-700">We operate with honesty and transparency in every interaction, from pricing to itinerary planning.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mr-6">
                        <i class="fas fa-leaf text-green-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold mb-2">Sustainability</h3>
                        <p class="text-gray-700">We minimize our environmental impact and actively support conservation efforts in the Himalayas.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mr-6">
                        <i class="fas fa-star text-purple-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold mb-2">Excellence</h3>
                        <p class="text-gray-700">We continuously improve our services and never settle for "good enough"—we strive for exceptional.</p>
                    </div>
                </div>

                <div class="flex items-start">
                    <div class="flex-shrink-0 w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mr-6">
                        <i class="fas fa-handshake text-orange-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold mb-2">Respect</h3>
                        <p class="text-gray-700">Deep respect for local culture, traditions, and the natural environment guides everything we do.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Certifications & Licenses -->
<section class="py-20 bg-gray-100">
    <div class="container mx-auto px-4">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-bold mb-4">Registered & Certified</h2>
            <p class="text-xl text-gray-600">Fully licensed and authorized by Government of Nepal</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div class="bg-white p-8 rounded-xl shadow-md text-center">
                <div class="text-6xl mb-4">🏔️</div>
                <h3 class="font-bold text-lg mb-2">Nepal Tourism Board</h3>
                <p class="text-gray-600 mb-2">License No: 1234/075</p>
                <p class="text-sm text-gray-500">Issued: 2014</p>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-md text-center">
                <div class="text-6xl mb-4">🎖️</div>
                <h3 class="font-bold text-lg mb-2">TAAN Member</h3>
                <p class="text-gray-600 mb-2">Trekking Agencies' Association of Nepal</p>
                <p class="text-sm text-gray-500">Member Since: 2014</p>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-md text-center">
                <div class="text-6xl mb-4">⛰️</div>
                <h3 class="font-bold text-lg mb-2">NMA Certified</h3>
                <p class="text-gray-600 mb-2">Nepal Mountaineering Association</p>
                <p class="text-sm text-gray-500">Certified Guides</p>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-4xl font-bold mb-6">Ready to Start Your Adventure?</h2>
        <p class="text-xl mb-8 max-w-2xl mx-auto">
            Join hundreds of happy trekkers who chose Yeti Routes for their Himalayan journey
        </p>
        <div class="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/treks" class="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fas fa-mountain mr-2"></i> Explore Our Treks
            </a>
            <a href="/contact" class="bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-full text-lg font-semibold transition">
                <i class="fas fa-envelope mr-2"></i> Contact Us Today
            </a>
        </div>
    </div>
</section>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/frontend.php';
?>
